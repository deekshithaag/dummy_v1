# Generic Handwritten-Form Extraction Pipeline

A production-grade, form-agnostic pipeline for extracting handwritten fields from scanned PDFs with non-LLM confidence scoring and self-repair.

---

# Architecture

```text
+--------------------------------------------------------------+
|                         extract.py (CLI)                     |
+--------------------------------------------------------------+
                |
                v
        +----------------+
        |  PDF Input     |
        +----------------+
                |
                v
        +----------------+
        | Preprocessor   | --> PDF-images, deskew, denoise,
        +----------------+     binarize
                |
                v
        +----------------+
        | Layout Analyzer| --> Detect regions, classify
        +----------------+     printed/handwritten
                |
                v
        +----------------+
        | Field Extractor| --> Spatial KV pairing,
        +----------------+     modality classification
                |
                v
        +----------------+
        | OCR Engine     |
        | (Multi)        |
        +----------------+
                |
                v
        +--------------------------+
        | Confidence Scorer        |
        | (Statistical)            |
        +--------------------------+
                |
                | 5 non-LLM signals
                v
          conf < 100%?
                |
               YES
                v
        +----------------+
        | Self-Repair    |
        | Loop           |
        +----------------+
                |
                | Escalating strategies
                v
          Still < 100%?
                |
               YES
                v
        +----------------------+
        | Uncorrectable Handler|
        +----------------------+
                |
                | Report with diagnostics
                v
        +----------------+
        | Output Assembler|
        +----------------+
                |
                v
           Structured JSON
```

---

# Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Run on a single PDF
python extract.py --input samples/form1.pdf --output output/form1.json

# Run with custom config
python extract.py --input samples/form1.pdf --output output/form1.json --config config/pipeline_config.yaml

# Run on all samples
python extract.py --input samples/ --output output/ --batch
```

---

# Confidence Scoring (Non-LLM)

Five independent, measurable signals are fused with modality-adaptive weights:

| Signal | Source | What it Measures |
|--------|--------|------------------|
| `S_ocr` | Per-character OCR engine confidence | Raw recognition certainty |
| `S_agreement` | Edit distance across 2 engines | Cross-validation reliability |
| `S_pattern` | Regex/checksum validation | Structural format validity |
| `S_quality` | Laplacian variance, contrast, skew | Input image quality |
| `S_linguistic` | Character n-gram frequency | Text plausibility |

**No signal comes from asking a model "How confident are you?" — all are deterministic or statistical.**

---

# Self-Repair Strategies

Applied in escalation order (cheapest computation first):

1. **Adaptive Binarization** — try Otsu → Sauvola → Niblack → Adaptive Gaussian
2. **Deskew + Denoise** — Hough transform + non-local means
3. **Region Re-crop** — expand bounding box 15%, retry OCR
4. **Super-Resolution** — bicubic 4× upscale + re-OCR
5. **Engine Rotation** — promote best secondary engine result
6. **Lexicon Correction** — Levenshtein to nearest valid pattern match

---

# Project Structure

```text
.
├── extract.py                      # CLI entry point
├── config/
│   └── pipeline_config.yaml        # All configurable parameters
├── pipeline/
│   ├── __init__.py
│   ├── preprocessor.py             # PDF + preprocessed images
│   ├── layout_analyzer.py          # Region detection + classification
│   ├── ocr_engine.py               # Multi-engine OCR wrapper
│   ├── field_extractor.py          # Form-agnostic KV pairing
│   ├── confidence_scorer.py        # 5-signal confidence fusion
│   ├── self_repair.py              # Repair loop with escalation
│   ├── uncorrectable_handler.py
│   └── output_assembler.py         # JSON output construction
├── utils/
│   ├── image_quality.py            # Blur, contrast, skew metrics
│   ├── pattern_validator.py        # Regex + checksum validators
│   ├── linguistic_model.py         # Character n-gram scorer
│   └── geometry.py                 # Spatial proximity helpers
├── samples/                        # Input PDFs
├── output/                         # Generated JSON outputs
├── docs/
│   ├── writeup.md                  # Technical write-up
│   └── sourcing.md                 # Document sourcing rationale
├── requirements.txt
└── README.md
```

---

# Requirements

- Python 3.9+
- No API keys required — fully open-source stack
- See `requirements.txt` for dependencies
