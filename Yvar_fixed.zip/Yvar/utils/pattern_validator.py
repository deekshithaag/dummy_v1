"""
Pattern Validator
Validates extracted text against known structural patterns.
Uses regex and checksum algorithms - fully deterministic, no LLM.
"""

import re
from typing import Optional
from dataclasses import dataclass


@dataclass
class PatternMatch:
    """Result of pattern validation."""
    is_valid: bool
    pattern_name: Optional[str]  # Which pattern matched
    match_score: float  # 0-1, how well it matches
    suggestion: Optional[str]  # Corrected value if close match


class PatternValidator:
    """
    Validates extracted text against structural patterns.
    Patterns are auto-matched (not tied to specific form types).
    """

    # Pattern definitions - order matters (most specific first)
    PATTERNS = {
        "aadhaar": {
            "regex": r"^\d{4}\s?\d{4}\s?\d{4}$",
            "description": "12-digit Aadhaar number",
            "checksum": "verhoeff",
        },
        "pan": {
            "regex": r"^[A-Z]{5}\d{4}[A-Z]$",
            "description": "PAN card number",
            "checksum": None,
        },
        "phone_india": {
            "regex": r"^(\+91[\s\-]?)?[6-9]\d{9}$",
            "description": "Indian phone number",
            "checksum": None,
        },
        "email": {
            "regex": r"^[\w\.\-]+@[\w\.\-]+\.[a-zA-Z]{2,}$",
            "description": "Email address",
            "checksum": None,
        },
        "date_dmy": {
            "regex": r"^\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2,4}$",
            "description": "Date DD/MM/YYYY",
            "checksum": None,
        },
        "date_ymd": {
            "regex": r"^\d{4}[/\-\.]\d{1,2}[/\-\.]\d{1,2}$",
            "description": "Date YYYY/MM/DD",
            "checksum": None,
        },
        "pincode": {
            "regex": r"^\d{6}$",
            "description": "Indian pincode",
            "checksum": None,
        },
        "percentage": {
            "regex": r"^\d{1,3}\.?\d{0,2}\s?%?$",
            "description": "Percentage value",
            "checksum": None,
        },
        "marks_fraction": {
            "regex": r"^\d{1,3}\s?[/|]\s?\d{1,3}$",
            "description": "Marks as fraction",
            "checksum": None,
        },
        "ifsc": {
            "regex": r"^[A-Z]{4}0[A-Z0-9]{6}$",
            "description": "Bank IFSC code",
            "checksum": None,
        },
        "vehicle_number": {
            "regex": r"^[A-Z]{2}\s?\d{1,2}\s?[A-Z]{1,3}\s?\d{4}$",
            "description": "Indian vehicle registration",
            "checksum": None,
        },
    }

    def validate(self, text: str, label: str = "") -> PatternMatch:
        """
        Validate text against all known patterns.
        Returns the best match (if any).
        """
        if not text or not text.strip():
            return PatternMatch(is_valid=False, pattern_name=None, match_score=0.0, suggestion=None)

        clean_text = text.strip()

        # Try each pattern
        for name, pattern_def in self.PATTERNS.items():
            regex = pattern_def["regex"]
            if re.match(regex, clean_text):
                # Full match - validate checksum if applicable
                if pattern_def.get("checksum") == "verhoeff":
                    if self._verhoeff_check(clean_text.replace(" ", "")):
                        return PatternMatch(is_valid=True, pattern_name=name, match_score=1.0, suggestion=None)
                    else:
                        return PatternMatch(
                            is_valid=False, pattern_name=name, match_score=0.8,
                            suggestion=None
                        )
                else:
                    return PatternMatch(is_valid=True, pattern_name=name, match_score=1.0, suggestion=None)

        # Check for near-matches (useful for self-repair)
        best_near_match = self._find_near_match(clean_text)
        if best_near_match:
            return best_near_match

        return PatternMatch(is_valid=False, pattern_name=None, match_score=0.0, suggestion=None)

    def _find_near_match(self, text: str) -> Optional[PatternMatch]:
        """Find patterns that almost match (for repair suggestions)."""
        # Check if text is close to a numeric pattern
        digits_only = re.sub(r'[^\d]', '', text)

        if len(digits_only) == 12:
            # Might be Aadhaar with OCR errors in separators
            formatted = f"{digits_only[:4]} {digits_only[4:8]} {digits_only[8:]}"
            return PatternMatch(
                is_valid=False, pattern_name="aadhaar_partial",
                match_score=0.7, suggestion=formatted
            )

        if len(digits_only) == 10 and digits_only[0] in "6789":
            # Might be phone number
            return PatternMatch(
                is_valid=False, pattern_name="phone_partial",
                match_score=0.6, suggestion=digits_only
            )

        return None

    def get_correction_candidates(self, text: str, pattern_name: str) -> list:
        """
        Generate correction candidates for a near-match.
        Used by the self-repair module.
        """
        candidates = []

        if pattern_name in ("aadhaar", "aadhaar_partial"):
            # Try common OCR confusions: 0-0, l-1, S-5, etc.
            corrected = self._apply_ocr_corrections(text, "numeric")
            candidates.append(corrected)
        elif pattern_name == "pan":
            corrected = self._apply_ocr_corrections(text, "pan")
            candidates.append(corrected)

        return candidates

    def _apply_ocr_corrections(self, text: str, context: str) -> str:
        """Apply common OCR confusion corrections."""
        corrections = {
            "numeric": {
                'O': '0', 'o': '0', 'l': '1', 'I': '1', 'i': '1',
                'S': '5', 's': '5', 'B': '8', 'Z': '2', 'z': '2',
                'G': '6', 'g': '9', 'A': '4', 'T': '7',
            },
            "pan": {
                '0': 'O', '1': 'I', 'S': '5', '5': 'S', '8': 'B',
            },
        }

        mapping = corrections.get(context, {})
        result = text
        for old, new in mapping.items():
            result = result.replace(old, new)
        return result

    # Verhoeff algorithm for Aadhaar checksum validation
    _VERHOEFF_TABLE_D = [
        [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
        [1, 2, 3, 4, 0, 6, 7, 8, 9, 5],
        [2, 3, 4, 0, 1, 7, 8, 9, 5, 6],
        [3, 4, 0, 1, 2, 8, 9, 5, 6, 7],
        [4, 0, 1, 2, 3, 9, 5, 6, 7, 8],
        [5, 9, 8, 7, 6, 0, 4, 3, 2, 1],
        [6, 5, 9, 8, 7, 1, 0, 4, 3, 2],
        [7, 6, 5, 9, 8, 2, 1, 0, 4, 3],
        [8, 7, 6, 5, 9, 3, 2, 1, 0, 4],
        [9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
    ]

    _VERHOEFF_TABLE_P = [
        [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
        [1, 5, 7, 6, 2, 8, 3, 0, 9, 4],
        [5, 8, 0, 3, 7, 9, 6, 1, 4, 2],
        [8, 9, 1, 6, 0, 4, 3, 5, 2, 7],
        [9, 4, 5, 3, 1, 2, 6, 8, 7, 0],
        [4, 2, 8, 6, 5, 7, 3, 9, 0, 1],
        [2, 7, 9, 3, 8, 0, 6, 4, 1, 5],
        [7, 0, 4, 6, 9, 1, 3, 8, 5, 2],
    ]

    _VERHOEFF_TABLE_INV = [0, 4, 3, 2, 1, 5, 6, 7, 8, 9]

    def _verhoeff_check(self, number: str) -> bool:
        """Validate Aadhaar number using Verhoeff checksum."""
        try:
            digits = [int(d) for d in str(number)]
        except ValueError:
            return False

        c = 0
        for i, digit in enumerate(reversed(digits)):
            c = self._VERHOEFF_TABLE_D[c][self._VERHOEFF_TABLE_P[i % 8][digit]]
        return c == 0
