"""
Linguistic Scorer
Character n-gram frequency analysis for text plausibility.
This is a STATISTICAL model, not an LLM. It measures how likely a character
sequence is based on pre-computed n-gram frequencies.
"""

import numpy as np
import re
from typing import Dict
from collections import defaultdict


class LinguisticScorer:
    """
    Scores text plausibility using character n-gram statistics.
    NOT an LLM - uses pre-computed frequency tables.

    Approach:
    - Character bigram and trigram frequencies for English
    - Penalizes unlikely character sequences (OCR artifacts)
    - Rewards common sequences (real words)
    """

    def __init__(self):
        # Pre-computed English character frequency distributions
        # Based on standard English letter frequencies
        self._char_freq = self._build_char_frequencies()
        self._bigram_freq = self._build_bigram_frequencies()
        self._trigram_freq = self._build_trigram_frequencies()

    def score(self, text: str) -> float:
        """
        Score text plausibility on 0-100 scale.
        Higher = more linguistically plausible.
        """
        if not text or len(text.strip()) < 2:
            return 50.0  # Neutral for very short text

        text = text.strip().lower()

        # Component scores
        char_score = self._char_frequency_score(text)
        bigram_score = self._bigram_score(text)
        trigram_score = self._trigram_score(text)
        structure_score = self._structural_score(text)

        # Weighted combination
        final = (
            0.15 * char_score
            + 0.30 * bigram_score
            + 0.30 * trigram_score
            + 0.25 * structure_score
        )

        return max(0.0, min(100.0, final))

    def _char_frequency_score(self, text: str) -> float:
        """Score based on individual character frequencies."""
        if not text:
            return 0.0

        alpha_chars = [c for c in text if c.isalpha()]
        if not alpha_chars:
            return 50.0  # Neutral for non-alpha text

        scores = []
        for c in alpha_chars:
            freq = self._char_freq.get(c, 0.001)
            # Normalize: common letters get high scores
            score = min(100.0, freq * 1000)
            scores.append(score)

        return float(np.mean(scores))

    def _bigram_score(self, text: str) -> float:
        """Score based on character bigram frequencies."""
        if len(text) < 2:
            return 50.0

        alpha_text = re.sub(r'[^a-z ]', '', text)
        if len(alpha_text) < 2:
            return 50.0

        scores = []
        for i in range(len(alpha_text) - 1):
            bigram = alpha_text[i:i+2]
            freq = self._bigram_freq.get(bigram, 0.0001)
            # Log-scale scoring
            score = max(0, 50 + 10 * np.log10(freq * 10000))
            scores.append(score)

        if not scores:
            return 50.0

        return float(np.mean(scores))

    def _trigram_score(self, text: str) -> float:
        """Score based on character trigram frequencies."""
        if len(text) < 3:
            return 50.0

        alpha_text = re.sub(r'[^a-z ]', '', text)
        if len(alpha_text) < 3:
            return 50.0

        scores = []
        for i in range(len(alpha_text) - 2):
            trigram = alpha_text[i:i+3]
            freq = self._trigram_freq.get(trigram, 0.00001)
            # Log-scale scoring
            score = max(0, 50 + 8 * np.log10(freq * 100000))
            scores.append(score)

        if not scores:
            return 50.0

        return float(np.mean(scores))

    def _structural_score(self, text: str) -> float:
        """
        Score structural properties:
        - Reasonable word lengths
        - No excessive consecutive consonants/vowels
        - Proper spacing patterns
        """
        score = 70.0  # Start with reasonable base

        # Check for garbage patterns
        # Excessive repeated characters
        if re.search(r'(.)\1{3,}', text):
            score -= 30.0

        # Too many consecutive consonants (unlikely in English)
        consonants = 'bcdfghjklmnpqrstvwxyz'
        if re.search(f'[{consonants}]{{5,}}', text):
            score -= 20.0

        # Too many consecutive vowels
        vowels = 'aeiou'
        if re.search(f'[{vowels}]{{4,}}', text):
            score -= 15.0

        # Check word lengths
        words = text.split()
        if words:
            avg_len = np.mean([len(w) for w in words])
            if avg_len > 15:  # Unusually long "words" = likely OCR garbage
                score -= 25.0
            elif avg_len < 1.5:  # Too many single chars
                score -= 15.0

        # No spaces in long text = likely OCR run-together
        if len(text) > 15 and ' ' not in text and not text.isdigit():
            score -= 20.0

        return max(0.0, min(100.0, score))

    def _build_char_frequencies(self) -> Dict[str, float]:
        """Standard English character frequencies."""
        return {
            'e': 0.127, 't': 0.091, 'a': 0.082, 'o': 0.075, 'i': 0.070,
            'n': 0.067, 's': 0.063, 'h': 0.061, 'r': 0.060, 'd': 0.043,
            'l': 0.040, 'c': 0.028, 'u': 0.028, 'm': 0.024, 'w': 0.024,
            'f': 0.022, 'g': 0.020, 'y': 0.020, 'p': 0.019, 'b': 0.015,
            'v': 0.010, 'k': 0.008, 'j': 0.002, 'x': 0.002, 'q': 0.001,
            'z': 0.001, ' ': 0.130,
        }

    def _build_bigram_frequencies(self) -> Dict[str, float]:
        """Common English character bigrams."""
        # Top ~100 English bigrams with approximate frequencies
        return {
            'th': 0.037, 'he': 0.033, 'in': 0.024, 'er': 0.021, 'an': 0.020,
            'on': 0.017, 'en': 0.017, 're': 0.017, 'nd': 0.016, 'at': 0.015,
            'or': 0.014, 'es': 0.013, 'ti': 0.013, 'te': 0.012, 'ed': 0.012,
            'to': 0.011, 'it': 0.011, 'al': 0.011, 'ar': 0.011, 'st': 0.010,
            'ng': 0.010, 'se': 0.010, 'ha': 0.010, 'as': 0.009,
            'ou': 0.009, 'io': 0.008, 'le': 0.008, 've': 0.008,
            'co': 0.008, 'me': 0.008, 'de': 0.008, 'hi': 0.007, 'ri': 0.007,
            'ro': 0.007, 'ic': 0.007, 'ne': 0.007, 'ea': 0.007, 'ra': 0.007,
            'ce': 0.006, 'li': 0.006, 'ch': 0.006, 'll': 0.006, 'be': 0.006,
            'ma': 0.006, 'si': 0.006, 'om': 0.006, 'ur': 0.006, 't ': 0.020,
            'a ': 0.015, 's ': 0.010, 'i ': 0.009, 'e ': 0.018,
            'd ': 0.010, 'n ': 0.008, 'of': 0.009,
            'el': 0.005, 'no': 0.005, 'na': 0.005, 'us': 0.005, 'ss': 0.005,
            'ta': 0.005, 'la': 0.005, 'di': 0.005, 'fo': 0.005, 'ho': 0.005,
            'pe': 0.005, 'ec': 0.005, 'pr': 0.005, 'il': 0.005, 'lo': 0.005,
        }

    def _build_trigram_frequencies(self) -> Dict[str, float]:
        """Common English character trigrams."""
        return {
            'the': 0.035, 'and': 0.016, 'ing': 0.011, 'ion': 0.010, 'tio': 0.009,
            'ent': 0.008, 'ati': 0.008, 'for': 0.008, 'her': 0.007, 'ter': 0.007,
            'hat': 0.007, 'tha': 0.007, 'ere': 0.006, 'ate': 0.006, 'his': 0.006,
            'con': 0.006, 'res': 0.006, 'ver': 0.006, 'all': 0.005, 'ons': 0.005,
            'nce': 0.005, 'men': 0.005, 'ith': 0.005, 'ted': 0.005, 'ers': 0.005,
            'pro': 0.005, 'thi': 0.005, 'wit': 0.005, 'are': 0.005, 'ess': 0.005,
            'not': 0.004, 'ive': 0.004, 'was': 0.004, 'ect': 0.004, 'rea': 0.004,
            'com': 0.004, 'eve': 0.004, 'int': 0.004, 'est': 0.004, 'sta': 0.004,
            'eni': 0.003, 'ght': 0.003, 'igh': 0.003, 'ble': 0.003,
            'der': 0.003, 'ove': 0.003, 'ine': 0.003, 'tur': 0.003, 'per': 0.003,
            'man': 0.003, 'pre': 0.003, 'oun': 0.003, 'str': 0.003, 'ort': 0.003,
            'nal': 0.003, 'ste': 0.003, 'nde': 0.003, 'ind': 0.003, 'ore': 0.003,
        }
