"""
Debug Visualizer
Generates visual debug outputs: bounding box overlays, confidence heatmaps,
and repaired region crops for demo and diagnostics.
"""

import os
import numpy as np
import cv2
from typing import List, Optional, Tuple, Dict


def _confidence_color(confidence: float) -> Tuple[int, int, int]:
    """Map confidence (0-100) to BGR color: red-yellow-green."""
    ratio = max(0.0, min(1.0, confidence / 100.0))
    if ratio < 0.5:
        # Red to Yellow
        r = 255
        g = int(255 * (ratio / 0.5))
    else:
        # Yellow to Green
        r = int(255 * ((1.0 - ratio) / 0.5))
        g = 255
    return (0, g, r)  # BGR


def draw_field_overlay(
    image: np.ndarray,
    fields: list,
    confidences: list,
    output_path: str,
    page_number: int = 1,
):
    """
    Draw bounding boxes color-coded by confidence on the page image.

    Green = high confidence, Yellow = medium, Red = low.
    """
    if len(image.shape) == 2:
        canvas = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    else:
        canvas = image.copy()

    for field, conf in zip(fields, confidences):
        bbox = field.value_bbox or field.bbox
        x1, y1, x2, y2 = bbox
        score = conf.final_score if hasattr(conf, "final_score") else conf
        color = _confidence_color(score)
        thickness = 2

        # Draw bounding box
        cv2.rectangle(canvas, (x1, y1), (x2, y2), color, thickness)

        # Draw label + confidence text
        label_text = f"{field.label}: {score:.0f}%"
        font = cv2.FONT_HERSHEY_SIMPLEX
        font_scale = 0.4
        text_size = cv2.getTextSize(label_text, font, font_scale, 1)[0]

        # Background rectangle for text readability
        cv2.rectangle(
            canvas,
            (x1, y1 - text_size[1] - 6),
            (x1 + text_size[0] + 4, y1),
            color,
            -1,
        )
        cv2.putText(
            canvas, label_text,
            (x1 + 2, y1 - 4),
            font, font_scale, (255, 255, 255), 1, cv2.LINE_AA,
        )

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    cv2.imwrite(output_path, canvas)


def draw_confidence_heatmap(
    image: np.ndarray,
    fields: list,
    confidences: list,
    output_path: str,
):
    """
    Generate a confidence heatmap overlay on the page.
    Low-confidence regions glow red; high-confidence regions stay neutral.
    """
    if len(image.shape) == 2:
        canvas = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    else:
        canvas = image.copy()

    overlay = canvas.copy()

    for field, conf in zip(fields, confidences):
        bbox = field.value_bbox or field.bbox
        x1, y1, x2, y2 = bbox
        score = conf.final_score if hasattr(conf, "final_score") else conf

        # Only highlight sub-100% fields
        if score >= 100.0:
            continue

        alpha = max(0.1, min(0.6, (100.0 - score) / 100.0))
        color = _confidence_color(score)

        cv2.rectangle(overlay, (x1, y1), (x2, y2), color, -1)
        cv2.addWeighted(overlay, alpha, canvas, 1 - alpha, 0, canvas)
        overlay = canvas.copy()

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    cv2.imwrite(output_path, canvas)


def save_repaired_crops(
    page_image: np.ndarray,
    fields: list,
    repair_results: list,
    output_dir: str,
):
    """
    Save cropped images of fields that went through repair,
    showing original region alongside repaired value.
    """
    os.makedirs(output_dir, exist_ok=True)

    for field, repair in zip(fields, repair_results):
        if repair is None or not repair.is_repaired:
            continue

        bbox = field.value_bbox or field.bbox
        x1, y1, x2, y2 = bbox

        if len(page_image.shape) == 2:
            crop = page_image[y1:y2, x1:x2]
        else:
            crop = page_image[y1:y2, x1:x2]

        if crop.size == 0:
            continue

        # Add annotation bar below the crop
        h, w = crop.shape[:2]
        if len(crop.shape) == 2:
            crop_bgr = cv2.cvtColor(crop, cv2.COLOR_GRAY2BGR)
        else:
            crop_bgr = crop.copy()

        bar_height = 40
        bar = np.zeros((bar_height, w, 3), dtype=np.uint8)

        text = f"'{repair.original_value}' -> '{repair.final_value}' [{repair.original_confidence:.0f}%->{repair.final_confidence:.0f}%]"
        font = cv2.FONT_HERSHEY_SIMPLEX
        cv2.putText(bar, text, (4, 25), font, 0.35, (255, 255, 255), 1, cv2.LINE_AA)

        annotated = np.vstack([crop_bgr, bar])

        safe_label = field.label.replace("/", "_").replace(" ", "_")[:30]
        filename = f"{field.field_id}_{safe_label}_repaired.png"
        cv2.imwrite(os.path.join(output_dir, filename), annotated)


def generate_debug_outputs(
    page_image: np.ndarray,
    fields: list,
    confidences: list,
    repair_results: list,
    output_dir: str,
    page_number: int = 1,
):
    """
    Generate all debug visualizations for a page.

    Creates:
      - page_N_fields.png    -- bounding box overlay
      - page_N_heatmap.png   -- confidence heatmap
      - repairs/             -- cropped repaired regions
    """
    debug_dir = os.path.join(output_dir, "debug")
    os.makedirs(debug_dir, exist_ok=True)

    draw_field_overlay(
        page_image, fields, confidences,
        os.path.join(debug_dir, f"page_{page_number}_fields.png"),
        page_number=page_number,
    )

    draw_confidence_heatmap(
        page_image, fields, confidences,
        os.path.join(debug_dir, f"page_{page_number}_heatmap.png"),
    )

    save_repaired_crops(
        page_image, fields, repair_results,
        os.path.join(debug_dir, "repairs"),
    )
