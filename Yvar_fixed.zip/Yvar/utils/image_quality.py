"""
Image Quality Metrics
Computes blur, contrast, noise, and skew metrics for a region.
All metrics are deterministic and measurable.
"""

import numpy as np
import cv2
from dataclasses import dataclass


@dataclass
class ImageQualityMetrics:
    """Quality metrics for an image region."""
    laplacian_variance: float  # Higher = sharper (blur detector)
    contrast_ratio: float      # Std dev of pixel values / 255
    snr: float                 # Estimated signal-to-noise ratio
    skew_estimate: float       # Estimated skew angle in degrees
    mean_intensity: float      # Average brightness
    dynamic_range: float       # Range of pixel values / 255


def compute_region_quality(image: np.ndarray) -> ImageQualityMetrics:
    """
    Compute image quality metrics for a region.
    Used as confidence signal - poor quality images produce unreliable OCR.
    """
    # Convert to grayscale if needed
    if len(image.shape) == 3:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    else:
        gray = image.copy()

    if gray.size == 0:
        return ImageQualityMetrics(
            laplacian_variance=0.0,
            contrast_ratio=0.0,
            snr=0.0,
            skew_estimate=0.0,
            mean_intensity=0.0,
            dynamic_range=0.0,
        )

    # 1. Blur detection: Laplacian variance
    # Low variance = blurry image
    laplacian = cv2.Laplacian(gray, cv2.CV_64F)
    lap_var = float(laplacian.var())

    # 2. Contrast: standard deviation of pixel values
    contrast = float(np.std(gray) / 255.0)

    # 3. Signal-to-noise ratio estimate
    # Use local variance method
    snr = _estimate_snr(gray)

    # 4. Skew estimate (simple version using projection profile)
    skew = _estimate_local_skew(gray)

    # 5. Mean intensity
    mean_intensity = float(np.mean(gray) / 255.0)

    # 6. Dynamic range
    dynamic_range = float((np.max(gray) - np.min(gray)) / 255.0)

    return ImageQualityMetrics(
        laplacian_variance=lap_var,
        contrast_ratio=contrast,
        snr=snr,
        skew_estimate=skew,
        mean_intensity=mean_intensity,
        dynamic_range=dynamic_range,
    )


def _estimate_snr(gray: np.ndarray) -> float:
    """
    Estimate signal-to-noise ratio using local variance method.
    Higher SNR = cleaner image.
    """
    # Signal power: variance of the whole image
    signal_var = np.var(gray.astype(np.float64))

    # Noise estimate: median of local variances in small patches
    h, w = gray.shape
    patch_size = min(8, h // 2, w // 2)
    if patch_size < 2:
        return 0.0

    local_vars = []
    for y in range(0, h - patch_size, patch_size):
        for x in range(0, w - patch_size, patch_size):
            patch = gray[y:y+patch_size, x:x+patch_size].astype(np.float64)
            local_vars.append(np.var(patch))

    if not local_vars:
        return 0.0

    noise_var = np.median(local_vars)

    if noise_var < 1e-10:
        return 20.0  # Very clean image

    snr = 10 * np.log10(signal_var / noise_var) if signal_var > noise_var else 0.0
    return max(0.0, float(snr))


def _estimate_local_skew(gray: np.ndarray) -> float:
    """Estimate local skew of text in the region."""
    # Simple approach: use horizontal projection and find tilt
    h, w = gray.shape
    if h < 10 or w < 10:
        return 0.0

    # Binary threshold
    _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

    # Try small angles and find which gives sharpest horizontal projection
    best_angle = 0.0
    best_score = 0.0

    for angle_10x in range(-50, 51, 5):  # -5 to +5 degrees in 0.5 steps
        angle = angle_10x / 10.0
        center = (w // 2, h // 2)
        M = cv2.getRotationMatrix2D(center, angle, 1.0)
        rotated = cv2.warpAffine(binary, M, (w, h))

        # Horizontal projection profile
        projection = np.sum(rotated, axis=1)
        # Score: variance of projection (higher = more aligned)
        score = np.var(projection)
        if score > best_score:
            best_score = score
            best_angle = angle

    return best_angle
