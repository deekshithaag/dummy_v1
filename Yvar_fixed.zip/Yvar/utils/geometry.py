"""
Geometry Utilities
Spatial proximity calculations for form-agnostic field pairing.
"""

import numpy as np
from typing import Tuple, List


def bbox_iou(bbox1: Tuple[int, int, int, int], bbox2: Tuple[int, int, int, int]) -> float:
    """Compute Intersection over Union between two bounding boxes."""
    x1 = max(bbox1[0], bbox2[0])
    y1 = max(bbox1[1], bbox2[1])
    x2 = min(bbox1[2], bbox2[2])
    y2 = min(bbox1[3], bbox2[3])

    intersection = max(0, x2 - x1) * max(0, y2 - y1)
    area1 = (bbox1[2] - bbox1[0]) * (bbox1[3] - bbox1[1])
    area2 = (bbox2[2] - bbox2[0]) * (bbox2[3] - bbox2[1])
    union = area1 + area2 - intersection

    if union == 0:
        return 0.0
    return intersection / union


def bbox_center(bbox: Tuple[int, int, int, int]) -> Tuple[float, float]:
    """Get center point of a bounding box."""
    return ((bbox[0] + bbox[2]) / 2, (bbox[1] + bbox[3]) / 2)


def bbox_area(bbox: Tuple[int, int, int, int]) -> int:
    """Get area of a bounding box."""
    return (bbox[2] - bbox[0]) * (bbox[3] - bbox[1])


def expand_bbox(
    bbox: Tuple[int, int, int, int], ratio: float,
    max_w: int, max_h: int
) -> Tuple[int, int, int, int]:
    """Expand bounding box by a ratio while staying within image bounds."""
    x1, y1, x2, y2 = bbox
    w = x2 - x1
    h = y2 - y1
    dx = int(w * ratio)
    dy = int(h * ratio)

    return (
        max(0, x1 - dx),
        max(0, y1 - dy),
        min(max_w, x2 + dx),
        min(max_h, y2 + dy),
    )


def is_horizontally_aligned(
    bbox1: Tuple[int, int, int, int],
    bbox2: Tuple[int, int, int, int],
    tolerance: float = 0.5
) -> bool:
    """Check if two bboxes are roughly on the same horizontal line."""
    cy1 = (bbox1[1] + bbox1[3]) / 2
    cy2 = (bbox2[1] + bbox2[3]) / 2
    h1 = bbox1[3] - bbox1[1]
    h2 = bbox2[3] - bbox2[1]
    max_h = max(h1, h2)

    return abs(cy1 - cy2) < max_h * tolerance


def is_vertically_aligned(
    bbox1: Tuple[int, int, int, int],
    bbox2: Tuple[int, int, int, int],
    tolerance: float = 0.5
) -> bool:
    """Check if two bboxes are roughly on the same vertical line."""
    cx1 = (bbox1[0] + bbox1[2]) / 2
    cx2 = (bbox2[0] + bbox2[2]) / 2
    w1 = bbox1[2] - bbox1[0]
    w2 = bbox2[2] - bbox2[0]
    max_w = max(w1, w2)

    return abs(cx1 - cx2) < max_w * tolerance


def reading_order_sort(bboxes: List[Tuple[int, int, int, int]], line_threshold: int = 30) -> List[int]:
    """
    Sort bounding boxes in reading order (top-to-bottom, left-to-right).
    Groups boxes on similar y-coordinates as same line.
    Returns indices in sorted order.
    """
    if not bboxes:
        return []

    # Group by approximate y-position (same line)
    indexed = list(enumerate(bboxes))
    indexed.sort(key=lambda x: x[1][1])  # Sort by y1

    lines = []
    current_line = [indexed[0]]

    for i in range(1, len(indexed)):
        curr_y = indexed[i][1][1]
        prev_y = current_line[-1][1][1]

        if curr_y - prev_y < line_threshold:
            current_line.append(indexed[i])
        else:
            lines.append(current_line)
            current_line = [indexed[i]]

    lines.append(current_line)

    # Sort each line by x-position
    sorted_indices = []
    for line in lines:
        line.sort(key=lambda x: x[1][0])  # Sort by x1
        sorted_indices.extend([idx for idx, _ in line])

    return sorted_indices
