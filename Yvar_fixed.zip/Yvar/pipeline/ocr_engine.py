"""
Multi-Engine OCR Module
Runs multiple OCR engines on detected regions for cross-validation.
"""

import numpy as np
import cv2
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)

@dataclass
class OCRResult:
    """Result from a single OCR engine."""
    engine: str
    text: str
    char_confidences: List[float]  # per-character confidence 0-1
    overall_confidence: float  # average confidence 0-1
    bbox: Optional[Tuple[int, int, int, int]] = None

@dataclass
class MultiOCRResult:
    """Combined results from multiple OCR engines."""
    primary: OCRResult
    secondary: List[OCRResult]
    all_texts: List[str]
    best_text: str
    best_confidence: float


class OCREngine:
    """
    Multi-engine OCR wrapper.
    Runs PaddleOCR and EasyOCR for cross-validation.
    No system-level binaries required - fully pip-installable.
    """

    def __init__(self, config: dict):
        self.primary_engine = config.get("primary", "paddleocr")
        self.secondary_engines = config.get("secondary", ["easyocr"])
        self.languages = config.get("languages", ["en"])
        self.engine_config = config

        # Lazy initialization
        self._paddle = None
        self._easyocr = None

    def _get_paddle(self):
        """Lazy-load PaddleOCR."""
        if self._paddle is None:
            from paddleocr import PaddleOCR
            paddle_cfg = self.engine_config.get("paddleocr", {})
            self._paddle = PaddleOCR(
                lang=paddle_cfg.get("lang", "en"),
                use_doc_orientation_classify=False,
                use_doc_unwarping=False,
                use_textline_orientation=False,
            )
        return self._paddle

    def _get_easyocr(self):
        """Lazy-load EasyOCR."""
        if self._easyocr is None:
            import easyocr
            self._easyocr = easyocr.Reader(self.languages, gpu=False)
        return self._easyocr

    def recognize_region(
        self,
        image: np.ndarray,
        bbox: Tuple[int, int, int, int],
        run_secondary: bool = True
    ) -> MultiOCRResult:
        """
        Run OCR on a specific image region using multiple engines.

        Args:
            image: Full page image (grayscale or RGB)
            bbox: Region bounding box (x1, y1, x2, y2)
            run_secondary: Whether to run secondary engines for cross-validation

        Returns:
            MultiOCRResult with all engine outputs
        """
        x1, y1, x2, y2 = bbox
        region = image[y1:y2, x1:x2]

        if region.size == 0:
            empty = OCRResult(engine="none", text="", char_confidences=[], overall_confidence=0.0)
            return MultiOCRResult(
                primary=empty, secondary=[], all_texts=[""],
                best_text="", best_confidence=0.0
            )

        # Run primary engine
        primary_result = self._run_engine(region, self.primary_engine)

        # Run secondary engines
        secondary_results = []
        if run_secondary:
            for engine_name in self.secondary_engines:
                try:
                    result = self._run_engine(region, engine_name)
                    secondary_results.append(result)
                except Exception as e:
                    logger.warning(f"Secondary engine {engine_name} failed: {e}")

        # Determine best result
        all_results = [primary_result] + secondary_results
        all_texts = [r.text for r in all_results]

        best_result = max(all_results, key=lambda r: r.overall_confidence)

        return MultiOCRResult(
            primary=primary_result,
            secondary=secondary_results,
            all_texts=all_texts,
            best_text=best_result.text,
            best_confidence=best_result.overall_confidence,
        )

    def _run_engine(self, region: np.ndarray, engine_name: str) -> OCRResult:
        """Run a specific OCR engine on a region."""
        if engine_name == "paddleocr":
            return self._run_paddle(region)
        elif engine_name == "easyocr":
            return self._run_easyocr(region)
        else:
            raise ValueError(f"Unknown OCR engine: {engine_name}")

    def _run_paddle(self, region: np.ndarray) -> OCRResult:
        """Run PaddleOCR on a region."""
        try:
            paddle = self._get_paddle()

            # PaddleOCR expects BGR or RGB
            if len(region.shape) == 2:
                region_rgb = cv2.cvtColor(region, cv2.COLOR_GRAY2RGB)
            else:
                region_rgb = region

            result = paddle.predict(region_rgb)

            # PaddleOCR v3.5 returns a list of result dicts
            texts = []
            confidences = []

            if result:
                for page_result in result:
                    rec_texts = page_result.get('rec_texts', [])
                    rec_scores = page_result.get('rec_scores', [])
                    for txt, score in zip(rec_texts, rec_scores):
                        if txt.strip():
                            texts.append(txt)
                            confidences.append(float(score))

            if not texts:
                return OCRResult(
                    engine="paddleocr", text="",
                    char_confidences=[], overall_confidence=0.0
                )

            combined_text = " ".join(texts)
            avg_conf = np.mean(confidences) if confidences else 0.0

            # Distribute confidence to characters
            char_confs = []
            for text, conf in zip(texts, confidences):
                char_confs.extend([conf] * len(text))

            return OCRResult(
                engine="paddleocr",
                text=combined_text,
                char_confidences=char_confs,
                overall_confidence=float(avg_conf),
            )
        except Exception as e:
            logger.error(f"PaddleOCR failed: {e}")
            return OCRResult(engine="paddleocr", text="", char_confidences=[], overall_confidence=0.0)

    def _run_easyocr(self, region: np.ndarray) -> OCRResult:
        """Run EasyOCR on a region."""
        try:
            reader = self._get_easyocr()
            results = reader.readtext(region, detail=1, paragraph=False)

            if not results:
                return OCRResult(
                    engine="easyocr", text="",
                    char_confidences=[], overall_confidence=0.0
                )

            texts = []
            confidences = []
            for (bbox, text, conf) in results:
                texts.append(text)
                confidences.append(conf)

            combined_text = " ".join(texts)
            avg_conf = np.mean(confidences) if confidences else 0.0

            # Distribute confidence to characters
            char_confs = []
            for text, conf in zip(texts, confidences):
                char_confs.extend([conf] * len(text))

            return OCRResult(
                engine="easyocr",
                text=combined_text,
                char_confidences=char_confs,
                overall_confidence=float(avg_conf),
            )
        except Exception as e:
            logger.error(f"EasyOCR failed: {e}")
            return OCRResult(engine="easyocr", text="", char_confidences=[], overall_confidence=0.0)

    def detect_and_recognize_page(self, image: np.ndarray) -> list:
        """
        Run PaddleOCR on the full page and return per-text-line detections.

        Returns a list of dicts, each with:
            bbox: (x1, y1, x2, y2) axis-aligned bounding box
            polygon: original 4-point polygon from PaddleOCR
            text: recognized text
            confidence: recognition confidence 0-1
        """
        paddle = self._get_paddle()

        if len(image.shape) == 2:
            img_rgb = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
        else:
            img_rgb = image

        result = paddle.predict(img_rgb)

        detections = []
        if result:
            for page_result in result:
                rec_texts = page_result.get('rec_texts', [])
                rec_scores = page_result.get('rec_scores', [])
                rec_polys = page_result.get('rec_polys', [])

                for i, (txt, score) in enumerate(zip(rec_texts, rec_scores)):
                    if not txt.strip():
                        continue

                    # Convert polygon to axis-aligned bbox
                    if i < len(rec_polys):
                        poly = np.array(rec_polys[i])
                        x1 = int(poly[:, 0].min())
                        y1 = int(poly[:, 1].min())
                        x2 = int(poly[:, 0].max())
                        y2 = int(poly[:, 1].max())
                    else:
                        continue

                    detections.append({
                        'bbox': (x1, y1, x2, y2),
                        'polygon': rec_polys[i] if i < len(rec_polys) else None,
                        'text': txt,
                        'confidence': float(score),
                    })

        # Sort by reading order (top-to-bottom, left-to-right)
        detections.sort(key=lambda d: (d['bbox'][1] // 30, d['bbox'][0]))
        return detections

    def recognize_region_secondary(
        self,
        image: np.ndarray,
        bbox: tuple
    ) -> OCRResult:
        """Run only secondary engine (EasyOCR) on a region for cross-validation."""
        x1, y1, x2, y2 = bbox
        region = image[y1:y2, x1:x2]
        if region.size == 0:
            return OCRResult(engine="easyocr", text="", char_confidences=[], overall_confidence=0.0)
        return self._run_easyocr(region)

    def recognize_full_page(self, image: np.ndarray, engine: str = None) -> List[OCRResult]:
        """Run OCR on full page (used for initial structure detection)."""
        engine = engine or self.primary_engine
        result = self._run_engine(image, engine)
        return [result]
