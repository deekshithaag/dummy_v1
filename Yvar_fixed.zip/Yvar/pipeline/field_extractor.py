"""
Field Extractor Module
Form-agnostic key-value pairing using spatial analysis.
No hardcoded field names or per-form templates.
"""

import numpy as np
from typing import List, Optional
from dataclasses import dataclass
import logging

from pipeline.layout_analyzer import (
    LayoutAnalyzer, TextRegion, FormField, RegionType, FieldModality
)
from pipeline.ocr_engine import OCREngine, MultiOCRResult, OCRResult

logger = logging.getLogger(__name__)


@dataclass
class ExtractedField:
    """A fully extracted field with all metadata."""
    field_id: str
    label: str
    value: str
    modality: FieldModality
    bbox: tuple
    ocr_result: MultiOCRResult
    label_bbox: Optional[tuple] = None
    value_bbox: Optional[tuple] = None


class FieldExtractor:
    """
    Form-agnostic field extraction.
    Discovers key-value pairs using spatial layout analysis.
    No prior knowledge of form structure required.
    """

    def __init__(self, layout_config: dict, ocr_engine: OCREngine):
        self.layout_analyzer = LayoutAnalyzer(layout_config)
        self.ocr_engine = ocr_engine

    def extract_fields(self, page_image: np.ndarray, grayscale: np.ndarray) -> List[ExtractedField]:
        """
        Extract all fields from a page image.

        Pipeline:
        1. Run PaddleOCR on full page for detection + recognition
        2. For each detected text line, cross-validate with EasyOCR
        3. Classify field modality
        4. Generate labels from position/modality
        """
        # Step 1: Use PaddleOCR's native detection on the full page
        detections = self.ocr_engine.detect_and_recognize_page(page_image)
        logger.info(f"PaddleOCR detected {len(detections)} text regions")

        if not detections:
            # Fallback to morphological approach if PaddleOCR finds nothing
            return self._extract_fields_morphological(page_image, grayscale)

        # Step 2-3: For each detection, cross-validate + classify
        extracted_fields = []
        for i, det in enumerate(detections):
            bbox = det['bbox']
            paddle_text = det['text']
            paddle_conf = det['confidence']

            # Build primary OCR result from PaddleOCR's detection
            primary_result = OCRResult(
                engine="paddleocr",
                text=paddle_text,
                char_confidences=[paddle_conf] * len(paddle_text),
                overall_confidence=paddle_conf,
            )

            # Cross-validate with EasyOCR on the same tight bbox
            try:
                secondary_result = self.ocr_engine.recognize_region_secondary(
                    page_image, bbox
                )
            except Exception as e:
                logger.warning(f"EasyOCR cross-validation failed for region {i}: {e}")
                secondary_result = OCRResult(
                    engine="easyocr", text="", char_confidences=[], overall_confidence=0.0
                )

            # Build MultiOCRResult
            all_results = [primary_result, secondary_result]
            best = max(all_results, key=lambda r: r.overall_confidence)

            multi_ocr = MultiOCRResult(
                primary=primary_result,
                secondary=[secondary_result],
                all_texts=[primary_result.text, secondary_result.text],
                best_text=best.text,
                best_confidence=best.overall_confidence,
            )

            value_text = multi_ocr.best_text.strip()
            if not value_text:
                continue

            # Classify modality
            modality = self.layout_analyzer.classify_modality(value_text)

            # Generate label from position + modality
            label = self._generate_label_from_bbox(bbox, modality, grayscale.shape)

            field_id = f"field_{i+1:03d}"

            extracted_fields.append(ExtractedField(
                field_id=field_id,
                label=label,
                value=value_text,
                modality=modality,
                bbox=bbox,
                ocr_result=multi_ocr,
                label_bbox=None,
                value_bbox=bbox,
            ))

        logger.info(f"Extracted {len(extracted_fields)} fields")
        return extracted_fields

    def _extract_fields_morphological(self, page_image: np.ndarray, grayscale: np.ndarray) -> List[ExtractedField]:
        """Fallback: use morphological layout analysis (original approach)."""
        regions = self.layout_analyzer.analyze(page_image, grayscale)
        logger.info(f"Morphological fallback: {len(regions)} regions")

        if not regions:
            return []

        form_fields = self.layout_analyzer.pair_labels_and_values(regions)
        extracted_fields = []
        for field in form_fields:
            extracted = self._process_field(field, page_image)
            if extracted:
                extracted_fields.append(extracted)
        return extracted_fields

    def _generate_label_from_bbox(self, bbox: tuple, modality: FieldModality, img_shape: tuple) -> str:
        """Generate a descriptive label from bbox position and modality."""
        x1, y1, x2, y2 = bbox
        h, w = img_shape[:2]

        # Determine vertical zone
        rel_y = y1 / h
        if rel_y < 0.2:
            zone_v = "top"
        elif rel_y < 0.5:
            zone_v = "mid"
        elif rel_y < 0.8:
            zone_v = "lower"
        else:
            zone_v = "bottom"

        # Determine horizontal zone
        rel_x = x1 / w
        if rel_x < 0.33:
            zone_h = "left"
        elif rel_x < 0.66:
            zone_h = "center"
        else:
            zone_h = "right"

        modality_prefix = {
            FieldModality.NUMERIC: "num",
            FieldModality.TEXT: "text",
            FieldModality.SPECIAL: "id",
            FieldModality.MIXED: "mixed",
        }

        prefix = modality_prefix.get(modality, "field")
        return f"{prefix}_{zone_v}_{zone_h}"

    def _process_field(self, field: FormField, page_image: np.ndarray) -> Optional[ExtractedField]:
        """Process a single form field: OCR + modality classification."""
        # OCR the label (if exists)
        label_text = ""
        if field.label_region:
            label_ocr = self.ocr_engine.recognize_region(
                page_image, field.label_region.bbox, run_secondary=False
            )
            label_text = label_ocr.best_text.strip()
            # Clean label: remove trailing colons, dashes
            label_text = label_text.rstrip(':').rstrip('-').strip()

        # OCR the value region (with cross-validation)
        value_ocr = self.ocr_engine.recognize_region(
            page_image, field.value_region.bbox, run_secondary=True
        )
        value_text = value_ocr.best_text.strip()

        if not value_text and not label_text:
            return None

        # Classify modality
        modality = self.layout_analyzer.classify_modality(value_text)

        # Generate field label if none detected
        if not label_text:
            label_text = self._generate_label(field, modality)

        return ExtractedField(
            field_id=field.field_id,
            label=label_text,
            value=value_text,
            modality=modality,
            bbox=field.bbox,
            ocr_result=value_ocr,
            label_bbox=field.label_region.bbox if field.label_region else None,
            value_bbox=field.value_region.bbox,
        )

    def _generate_label(self, field: FormField, modality: FieldModality) -> str:
        """Generate a descriptive label for unlabeled fields."""
        # Use position and modality to create a generic label
        x1, y1, _, _ = field.value_region.bbox
        position = f"r{y1//100}_c{x1//100}"

        modality_prefix = {
            FieldModality.NUMERIC: "number",
            FieldModality.TEXT: "text",
            FieldModality.SPECIAL: "id",
            FieldModality.MIXED: "mixed",
        }

        prefix = modality_prefix.get(modality, "field")
        return f"{prefix}_{position}"
