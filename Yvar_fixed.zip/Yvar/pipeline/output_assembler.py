"""
Output Assembler
Constructs the final structured JSON output.
"""

import json
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from datetime import datetime

from pipeline.field_extractor import ExtractedField
from pipeline.confidence_scorer import ConfidenceBreakdown
from pipeline.self_repair import RepairResult
from pipeline.uncorrectable_handler import UncorrectableReport
from pipeline.layout_analyzer import FieldModality


@dataclass
class FieldOutput:
    """Final output format for a single field."""
    value: str
    confidence: float
    bounding_box: Dict[str, int]
    modality: str
    status: str  # "confirmed" | "repaired" | "uncorrectable"
    label: str
    repair_history: Optional[List[Dict]] = None
    uncorrectable_report: Optional[Dict] = None


class OutputAssembler:
    """Assembles the final JSON output from pipeline results."""

    def __init__(self, config: dict = None):
        config = config or {}
        self.include_bbox = config.get("include_bounding_box", True)
        self.include_repair_history = config.get("include_repair_history", True)
        self.human_review_threshold = config.get("human_review_threshold", 70)

    def assemble(
        self,
        fields: List[ExtractedField],
        confidence_scores: List[ConfidenceBreakdown],
        repair_results: List[Optional[RepairResult]],
        uncorrectable_reports: List[Optional[UncorrectableReport]],
        metadata: Dict[str, Any] = None,
    ) -> Dict[str, Any]:
        """
        Assemble final output JSON.

        Output format:
        {
            "metadata": { ... },
            "fields": { ... },
            "summary": { ... },
            "performance": { ... }
        }
        """
        output_fields = {}
        confirmed_count = 0
        repaired_count = 0
        uncorrectable_count = 0
        all_confs = []

        repair_attempted = sum(1 for r in repair_results if r is not None and r.attempts)
        repair_succeeded = sum(1 for r in repair_results if r is not None and r.is_repaired)
        total_repair_iters = sum(
            r.total_iterations for r in repair_results if r is not None
        )

        for i, field in enumerate(fields):
            confidence = confidence_scores[i] if i < len(confidence_scores) else None
            repair = repair_results[i] if i < len(repair_results) else None
            uncorrectable = uncorrectable_reports[i] if i < len(uncorrectable_reports) else None

            # Determine final value and status
            if uncorrectable:
                final_value = repair.final_value if repair else field.value
                final_confidence = confidence.final_score if confidence else 0.0
                status = "uncorrectable"
                uncorrectable_count += 1
            elif repair and repair.is_repaired:
                final_value = repair.final_value
                final_confidence = repair.final_confidence
                status = "repaired"
                repaired_count += 1
            else:
                final_value = field.value
                final_confidence = confidence.final_score if confidence else 0.0
                status = "confirmed"
                confirmed_count += 1

            all_confs.append(final_confidence)

            # Build field output
            field_output = {
                "value": final_value,
                "confidence": round(final_confidence, 2),
                "modality": field.modality.value,
                "status": status,
            }

            if self.include_bbox and field.bbox:
                x1, y1, x2, y2 = field.bbox
                field_output["bounding_box"] = {
                    "x1": int(x1), "y1": int(y1),
                    "x2": int(x2), "y2": int(y2),
                }

            if self.include_repair_history and repair and repair.attempts:
                field_output["repair_history"] = [
                    {
                        "strategy": a.strategy,
                        "value_before": a.value_before,
                        "value_after": a.value_after,
                        "confidence_change": round(a.improvement, 2),
                    }
                    for a in repair.attempts
                ]

            if uncorrectable:
                field_output["uncorrectable_report"] = {
                    "failure_type": uncorrectable.failure_type,
                    "failure_reason": uncorrectable.failure_reason,
                    "failure_signals": uncorrectable.failure_signals,
                    "confidence_gap": round(uncorrectable.confidence_gap, 2),
                    "recommended_action": uncorrectable.recommended_action,
                    "repair_attempts_count": len(uncorrectable.repair_attempts),
                }

            # Use label as key (deduplicate if needed)
            key = field.label or field.field_id
            if key in output_fields:
                key = f"{key}_{field.field_id}"
            output_fields[key] = field_output

        # Build summary
        total = len(fields)
        all_confs = [f["confidence"] for f in output_fields.values()]
        summary = {
            "total_fields": total,
            "confirmed": confirmed_count,
            "repaired": repaired_count,
            "uncorrectable": uncorrectable_count,
            "avg_confidence": round(sum(all_confs) / len(all_confs) if all_confs else 0, 2),
            "fields_above_threshold": sum(1 for c in all_confs if c >= 80.0),
            "fields_needing_review": sum(1 for c in all_confs if c < self.human_review_threshold),
        }

        # Build performance metrics
        performance = {
            "processing_time_seconds": (metadata or {}).get("processing_time_seconds", 0),
            "pages_processed": (metadata or {}).get("pages_processed", 0),
            "avg_latency_per_page": round(
                (metadata or {}).get("processing_time_seconds", 0) / max((metadata or {}).get("pages_processed", 1), 1), 1
            ),
            "repair_attempts_total": repair_attempted,
            "repair_success_count": repair_succeeded,
            "repair_success_rate": round(
                (repair_succeeded / max(repair_attempted, 1)) * 100, 1
            ),
            "total_repair_iterations": total_repair_iters,
            "avg_repair_iterations": round(
                total_repair_iters / max(repair_attempted, 1), 1
            ),
        }

        # Final output
        result = {
            "metadata": metadata or {
                "timestamp": datetime.now().isoformat(),
                "pipeline_version": "1.0.0",
            },
            "fields": output_fields,
            "summary": summary,
            "performance": performance,
        }

        return result

    def to_json(self, output: Dict[str, Any], indent: int = 2) -> str:
        """Serialize output dict to JSON string."""
        return json.dumps(output, indent=indent, ensure_ascii=False)
