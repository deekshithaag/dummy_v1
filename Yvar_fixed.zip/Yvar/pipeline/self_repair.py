"""
Self-Repair Loop
Attempts to improve low-confidence extractions using escalating strategies.
Re-scores after each attempt using the same non-LLM scoring approach.
"""

import numpy as np
import cv2
from typing import List, Optional, Tuple
from dataclasses import dataclass
import logging

from pipeline.ocr_engine import OCREngine, MultiOCRResult, OCRResult
from pipeline.confidence_scorer import ConfidenceScorer, ConfidenceBreakdown
from pipeline.layout_analyzer import FieldModality
from pipeline.preprocessor import Preprocessor
from utils.pattern_validator import PatternValidator

logger = logging.getLogger(__name__)


@dataclass
class RepairAttempt:
    """Record of a single repair attempt."""
    strategy: str
    description: str
    value_before: str
    value_after: str
    confidence_before: float
    confidence_after: float
    improvement: float
    success: bool


@dataclass
class RepairResult:
    """Final result after self-repair loop."""
    original_value: str
    final_value: str
    original_confidence: float
    final_confidence: float
    attempts: List[RepairAttempt]
    is_repaired: bool
    is_uncorrectable: bool
    total_iterations: int


class SelfRepairLoop:
    """
    Attempts to improve field extractions using escalating strategies.

    Strategy order (cheapest first):
    1. Adaptive binarization - try different thresholding methods
    2. Deskew + denoise - correct local skew and noise
    3. Region re-crop - expand bounding box and retry
    4. Super-resolution - upscale and re-OCR
    5. Engine rotation - try different OCR engine as primary
    6. Lexicon correction - pattern-based character substitution
    """

    def __init__(self, config: dict, preprocessor: Preprocessor,
                 ocr_engine: OCREngine, confidence_scorer: ConfidenceScorer):
        self.max_iterations = config.get("max_iterations", 6)
        self.min_improvement = config.get("min_improvement_threshold", 1.0)
        self.patience = config.get("no_improvement_patience", 2)
        self.strategies = config.get("strategies", [])
        self.confirm_threshold = config.get("confirm_threshold", 80.0)

        self.preprocessor = preprocessor
        self.ocr_engine = ocr_engine
        self.confidence_scorer = confidence_scorer
        self.pattern_validator = PatternValidator()

    def repair(
        self,
        current_value: str,
        current_confidence: ConfidenceBreakdown,
        page_image: np.ndarray,
        bbox: Tuple[int, int, int, int],
        modality: FieldModality,
        field_label: str = "",
        ocr_result: Optional[MultiOCRResult] = None,
    ) -> RepairResult:
        """
        Run self-repair loop on a field.

        Terminates when:
        - Confidence reaches 100%
        - N consecutive attempts show no improvement (patience exceeded)
        - All strategies exhausted
        """
        attempts = []
        best_value = current_value
        best_confidence = current_confidence.final_score
        no_improvement_count = 0

        logger.info(
            f"Starting repair for value='{current_value}' "
            f"confidence={best_confidence:.1f}% modality={modality.value}"
        )

        for i, strategy in enumerate(self._get_strategy_order()):
            if i >= self.max_iterations:
                break

            if best_confidence >= 100.0:
                break

            if no_improvement_count >= self.patience:
                logger.info(f"Patience exceeded after {no_improvement_count} attempts with no improvement")
                break

            # Execute repair strategy
            attempt = self._execute_strategy(
                strategy=strategy,
                current_value=best_value,
                current_confidence=best_confidence,
                page_image=page_image,
                bbox=bbox,
                modality=modality,
                field_label=field_label,
                ocr_result=ocr_result,
            )

            attempts.append(attempt)

            if attempt.improvement > self.min_improvement:
                best_value = attempt.value_after
                best_confidence = attempt.confidence_after
                no_improvement_count = 0
                logger.info(
                    f"  Strategy '{strategy['name']}' improved: "
                    f"{attempt.confidence_before:.1f}% -> {attempt.confidence_after:.1f}%"
                )
            else:
                no_improvement_count += 1
                logger.debug(
                    f"  Strategy '{strategy['name']}' no improvement: "
                    f"{attempt.confidence_after:.1f}%"
                )

        is_repaired = best_confidence > current_confidence.final_score
        is_uncorrectable = best_confidence < self.confirm_threshold

        return RepairResult(
            original_value=current_value,
            final_value=best_value,
            original_confidence=current_confidence.final_score,
            final_confidence=best_confidence,
            attempts=attempts,
            is_repaired=is_repaired,
            is_uncorrectable=is_uncorrectable,
            total_iterations=len(attempts),
        )

    def _get_strategy_order(self) -> List[dict]:
        """Get strategies in escalation order."""
        if self.strategies:
            return self.strategies

        # Default escalation order
        return [
            {"name": "adaptive_binarization", "description": "Try alternative binarization methods"},
            {"name": "clahe_enhance", "description": "CLAHE contrast enhancement for faded/uneven regions"},
            {"name": "deskew_denoise", "description": "Correct skew and apply denoising"},
            {"name": "region_recrop", "description": "Expand bounding box by 15% and re-OCR"},
            {"name": "super_resolution", "description": "4x upscale with interpolation + re-OCR"},
            {"name": "engine_rotation", "description": "Promote secondary engine result"},
            {"name": "lexicon_correction", "description": "Levenshtein distance to nearest valid pattern"},
        ]

    def _execute_strategy(
        self,
        strategy: dict,
        current_value: str,
        current_confidence: float,
        page_image: np.ndarray,
        bbox: Tuple[int, int, int, int],
        modality: FieldModality,
        field_label: str = "",
        ocr_result: Optional[MultiOCRResult] = None,
    ) -> RepairAttempt:
        """Execute a specific repair strategy."""
        strategy_name = strategy["name"]

        try:
            if strategy_name == "adaptive_binarization":
                new_value, new_ocr = self._strategy_adaptive_binarization(page_image, bbox)
            elif strategy_name == "clahe_enhance":
                new_value, new_ocr = self._strategy_clahe_enhance(page_image, bbox)
            elif strategy_name == "deskew_denoise":
                new_value, new_ocr = self._strategy_deskew_denoise(page_image, bbox)
            elif strategy_name == "region_recrop":
                new_value, new_ocr = self._strategy_region_recrop(page_image, bbox)
            elif strategy_name == "super_resolution":
                new_value, new_ocr = self._strategy_super_resolution(page_image, bbox)
            elif strategy_name == "engine_rotation":
                new_value, new_ocr = self._strategy_engine_rotation(page_image, bbox, ocr_result)
            elif strategy_name == "lexicon_correction":
                new_value, new_ocr = self._strategy_lexicon_correction(
                    current_value, modality, ocr_result
                )
            else:
                new_value = current_value
                new_ocr = ocr_result
        except Exception as e:
            logger.warning(f"Strategy {strategy_name} failed: {e}")
            new_value = current_value
            new_ocr = ocr_result

        # Re-score with same non-LLM scoring
        x1, y1, x2, y2 = bbox
        region = page_image[y1:y2, x1:x2]

        if new_ocr is None:
            # Create a minimal OCR result for scoring
            new_ocr = MultiOCRResult(
                primary=OCRResult(engine="repair", text=new_value, char_confidences=[], overall_confidence=0.5),
                secondary=[],
                all_texts=[new_value],
                best_text=new_value,
                best_confidence=0.5,
            )

        new_breakdown = self.confidence_scorer.rescore(
            text=new_value,
            ocr_result=new_ocr,
            region_image=region,
            modality=modality,
            field_label=field_label,
        )

        new_confidence = new_breakdown.final_score
        improvement = new_confidence - current_confidence

        return RepairAttempt(
            strategy=strategy_name,
            description=strategy.get("description", ""),
            value_before=current_value,
            value_after=new_value,
            confidence_before=current_confidence,
            confidence_after=new_confidence,
            improvement=improvement,
            success=improvement > self.min_improvement,
        )

    def _strategy_adaptive_binarization(
        self, page_image: np.ndarray, bbox: Tuple[int, int, int, int]
    ) -> Tuple[str, Optional[MultiOCRResult]]:
        """Try different binarization methods and pick the best OCR result."""
        methods = ["sauvola", "niblack", "adaptive_gaussian"]
        best_text = ""
        best_ocr = None
        best_conf = 0.0

        for method in methods:
            processed = self.preprocessor.reprocess_region(page_image, bbox, method=method)
            # Run OCR on reprocessed region
            h, w = processed.shape[:2]
            ocr_result = self.ocr_engine.recognize_region(
                processed, (0, 0, w, h), run_secondary=False
            )
            if ocr_result.primary.overall_confidence > best_conf:
                best_conf = ocr_result.primary.overall_confidence
                best_text = ocr_result.best_text
                best_ocr = ocr_result

        return best_text or "", best_ocr

    def _strategy_clahe_enhance(
        self, page_image: np.ndarray, bbox: Tuple[int, int, int, int]
    ) -> Tuple[str, Optional[MultiOCRResult]]:
        """Apply CLAHE contrast enhancement - effective for faded ink and uneven lighting."""
        processed = self.preprocessor.reprocess_region(page_image, bbox, method="clahe")
        h, w = processed.shape[:2]
        ocr_result = self.ocr_engine.recognize_region(
            processed, (0, 0, w, h), run_secondary=True
        )
        return ocr_result.best_text, ocr_result

    def _strategy_deskew_denoise(
        self, page_image: np.ndarray, bbox: Tuple[int, int, int, int]
    ) -> Tuple[str, Optional[MultiOCRResult]]:
        """Apply additional deskew and denoising to the region."""
        x1, y1, x2, y2 = bbox
        region = page_image[y1:y2, x1:x2]

        if len(region.shape) == 3:
            gray = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY)
        else:
            gray = region.copy()

        # Heavy denoising
        denoised = cv2.fastNlMeansDenoising(gray, None, h=15, templateWindowSize=7, searchWindowSize=21)

        # Local deskew
        skew = self.preprocessor._detect_skew(denoised)
        if abs(skew) > 0.5:
            denoised = self.preprocessor._deskew(denoised, skew)

        h, w = denoised.shape[:2]
        ocr_result = self.ocr_engine.recognize_region(denoised, (0, 0, w, h), run_secondary=True)
        return ocr_result.best_text, ocr_result

    def _strategy_region_recrop(
        self, page_image: np.ndarray, bbox: Tuple[int, int, int, int]
    ) -> Tuple[str, Optional[MultiOCRResult]]:
        """Expand bounding box and re-OCR."""
        processed = self.preprocessor.reprocess_region(
            page_image, bbox, method="otsu", expand_ratio=0.15
        )
        h, w = processed.shape[:2]
        ocr_result = self.ocr_engine.recognize_region(processed, (0, 0, w, h), run_secondary=True)
        return ocr_result.best_text, ocr_result

    def _strategy_super_resolution(
        self, page_image: np.ndarray, bbox: Tuple[int, int, int, int]
    ) -> Tuple[str, Optional[MultiOCRResult]]:
        """Upscale region and re-OCR."""
        x1, y1, x2, y2 = bbox
        region = page_image[y1:y2, x1:x2]

        if len(region.shape) == 3:
            gray = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY)
        else:
            gray = region.copy()

        # 4x upscale
        upscaled = self.preprocessor.super_resolve(gray, scale=4)

        h, w = upscaled.shape[:2]
        ocr_result = self.ocr_engine.recognize_region(upscaled, (0, 0, w, h), run_secondary=True)
        return ocr_result.best_text, ocr_result

    def _strategy_engine_rotation(
        self, page_image: np.ndarray, bbox: Tuple[int, int, int, int],
        original_ocr: Optional[MultiOCRResult] = None
    ) -> Tuple[str, Optional[MultiOCRResult]]:
        """Use a different engine's result if it has higher confidence."""
        if original_ocr and original_ocr.secondary:
            # Find secondary with highest confidence
            best_secondary = max(original_ocr.secondary, key=lambda r: r.overall_confidence)
            if best_secondary.overall_confidence > original_ocr.primary.overall_confidence:
                # Swap: use secondary as new primary
                new_result = MultiOCRResult(
                    primary=best_secondary,
                    secondary=[original_ocr.primary] + [
                        s for s in original_ocr.secondary if s != best_secondary
                    ],
                    all_texts=[best_secondary.text] + [original_ocr.primary.text],
                    best_text=best_secondary.text,
                    best_confidence=best_secondary.overall_confidence,
                )
                return best_secondary.text, new_result

        # Re-run with different engines
        x1, y1, x2, y2 = bbox
        region = page_image[y1:y2, x1:x2]
        h, w = region.shape[:2] if len(region.shape) == 2 else region.shape[:2]
        ocr_result = self.ocr_engine.recognize_region(region, (0, 0, w, h), run_secondary=True)
        return ocr_result.best_text, ocr_result

    def _strategy_lexicon_correction(
        self, current_value: str, modality: FieldModality,
        ocr_result: Optional[MultiOCRResult] = None
    ) -> Tuple[str, Optional[MultiOCRResult]]:
        """Apply pattern-based corrections for structured fields."""
        if not current_value:
            return current_value, ocr_result

        # Check for near-pattern matches and apply corrections
        match = self.pattern_validator.validate(current_value)

        if match.suggestion:
            return match.suggestion, ocr_result

        # Try common OCR corrections based on modality
        if modality == FieldModality.NUMERIC:
            corrected = self._correct_numeric_ocr_errors(current_value)
            if corrected != current_value:
                return corrected, ocr_result

        elif modality == FieldModality.SPECIAL:
            corrected = self._correct_special_char_errors(current_value)
            if corrected != current_value:
                return corrected, ocr_result

        return current_value, ocr_result

    def _correct_numeric_ocr_errors(self, text: str) -> str:
        """Fix common OCR errors in numeric fields."""
        corrections = {
            'O': '0', 'o': '0', 'l': '1', 'I': '1', 'i': '1',
            'S': '5', 's': '5', 'B': '8', 'Z': '2', 'z': '2',
            'G': '6', 'A': '4', 'T': '7', 'b': '6',
        }
        result = text
        for old, new in corrections.items():
            result = result.replace(old, new)
        return result

    def _correct_special_char_errors(self, text: str) -> str:
        """Fix common OCR errors in special character fields."""
        # Common confusions with separators
        corrections = {
            '|': '/', 'l': '/', '\\': '/',
            ',': '.', ';': ':',
        }
        result = text
        for old, new in corrections.items():
            # Only replace if it makes structural sense
            if old in result:
                result = result.replace(old, new)
        return result
