"""
Layout Analyzer Module
Detects text regions, classifies them as printed/handwritten,
and identifies form structure without templates.
"""

import numpy as np
import cv2
from typing import List, Tuple, Optional
from dataclasses import dataclass, field
from enum import Enum


class RegionType(Enum):
    PRINTED = "printed"
    HANDWRITTEN = "handwritten"
    MIXED = "mixed"
    UNKNOWN = "unknown"


class FieldModality(Enum):
    NUMERIC = "numeric"
    TEXT = "text"
    SPECIAL = "special"  # dates, IDs with special chars
    MIXED = "mixed"


@dataclass
class TextRegion:
    """A detected text region with classification."""
    bbox: Tuple[int, int, int, int]  # x1, y1, x2, y2
    region_type: RegionType
    confidence: float  # detection confidence
    contour: Optional[np.ndarray] = None
    text: str = ""
    stroke_width_variance: float = 0.0


@dataclass
class FormField:
    """A discovered form field (label + value pair)."""
    field_id: str
    label_region: Optional[TextRegion]
    value_region: TextRegion
    label_text: str = ""
    value_text: str = ""
    modality: FieldModality = FieldModality.TEXT
    bbox: Tuple[int, int, int, int] = (0, 0, 0, 0)


class LayoutAnalyzer:
    """
    Form-agnostic layout analysis.
    Detects text regions and classifies them without prior template knowledge.
    """

    def __init__(self, config: dict):
        self.region_conf_threshold = config.get("region_confidence_threshold", 0.5)
        self.label_value_max_dx = config.get("label_value_max_distance_x", 400)
        self.label_value_max_dy = config.get("label_value_max_distance_y", 80)
        self.swv_threshold = config.get("stroke_width_variance_threshold", 2.5)
        self.min_region_area = config.get("min_region_area", 200)

    def analyze(self, image: np.ndarray, grayscale: np.ndarray) -> List[TextRegion]:
        """
        Detect all text regions in the image.
        Uses connected component analysis + contour detection.
        """
        # Ensure we have a binary image for contour detection
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()

        # Adaptive threshold for region detection
        binary = cv2.adaptiveThreshold(
            gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY_INV, 31, 10
        )

        # Morphological operations to connect text characters into regions
        # Horizontal kernel to merge characters in a word/line
        h_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (15, 1))
        h_connected = cv2.dilate(binary, h_kernel, iterations=1)

        # Vertical kernel to merge nearby lines in same field
        v_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 3))
        connected = cv2.dilate(h_connected, v_kernel, iterations=1)

        # Light merge to consolidate close regions
        merge_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
        merged = cv2.dilate(connected, merge_kernel, iterations=1)

        # Find contours
        contours, _ = cv2.findContours(merged, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        regions = []
        for contour in contours:
            area = cv2.contourArea(contour)
            if area < self.min_region_area:
                continue

            x, y, w, h = cv2.boundingRect(contour)
            bbox = (x, y, x + w, y + h)

            # Classify region
            region_crop = grayscale[y:y+h, x:x+w]
            region_type, swv = self._classify_region(region_crop)

            region = TextRegion(
                bbox=bbox,
                region_type=region_type,
                confidence=min(1.0, area / 1000),  # Heuristic confidence based on size
                contour=contour,
                stroke_width_variance=swv,
            )
            regions.append(region)

        # Sort regions by reading order (top-to-bottom, left-to-right)
        regions.sort(key=lambda r: (r.bbox[1] // 50, r.bbox[0]))

        return regions

    def _classify_region(self, region: np.ndarray) -> Tuple[RegionType, float]:
        """
        Classify a region as printed or handwritten using stroke width variance.
        Printed text has uniform stroke width; handwriting stroke width varies.
        """
        if region.size == 0 or region.shape[0] < 5 or region.shape[1] < 5:
            return RegionType.UNKNOWN, 0.0

        # Binary inverse for stroke analysis
        _, binary = cv2.threshold(region, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

        # Distance transform to estimate stroke width
        dist = cv2.distanceTransform(binary, cv2.DIST_L2, 5)

        # Get stroke width values (non-zero pixels in distance transform)
        stroke_widths = dist[dist > 0]

        if len(stroke_widths) < 10:
            return RegionType.UNKNOWN, 0.0

        # Coefficient of variation of stroke width
        mean_sw = np.mean(stroke_widths)
        if mean_sw == 0:
            return RegionType.UNKNOWN, 0.0

        std_sw = np.std(stroke_widths)
        swv = std_sw / mean_sw  # Coefficient of variation

        if swv > self.swv_threshold:
            return RegionType.HANDWRITTEN, swv
        elif swv < self.swv_threshold * 0.5:
            return RegionType.PRINTED, swv
        else:
            return RegionType.MIXED, swv

    def pair_labels_and_values(self, regions: List[TextRegion]) -> List[FormField]:
        """
        Pair printed labels with handwritten values using spatial proximity.
        Form-agnostic: uses geometry only, no template knowledge.
        If pairing is not possible, returns all regions as standalone fields.
        """
        printed = [r for r in regions if r.region_type == RegionType.PRINTED]
        handwritten = [r for r in regions if r.region_type in (RegionType.HANDWRITTEN, RegionType.MIXED)]
        unknown = [r for r in regions if r.region_type == RegionType.UNKNOWN]

        # If no clear label/value separation, treat everything as standalone fields
        if not printed or not handwritten:
            return self._create_standalone_fields(regions)

        fields = []
        paired_values = set()
        field_counter = 0

        for label in printed:
            # Find nearest handwritten region to the right or below
            best_value = None
            best_distance = float("inf")

            for i, value in enumerate(handwritten):
                if i in paired_values:
                    continue

                dist, direction = self._spatial_distance(label.bbox, value.bbox)
                if dist < best_distance and direction in ("right", "below"):
                    best_distance = dist
                    best_value = (i, value)

            if best_value and best_distance < max(self.label_value_max_dx, self.label_value_max_dy):
                idx, value_region = best_value
                paired_values.add(idx)
                field_counter += 1

                fields.append(FormField(
                    field_id=f"field_{field_counter:03d}",
                    label_region=label,
                    value_region=value_region,
                    bbox=self._merge_bboxes(label.bbox, value_region.bbox),
                ))

        # Handle unpaired handwritten regions as standalone fields
        for i, value in enumerate(handwritten):
            if i not in paired_values:
                field_counter += 1
                fields.append(FormField(
                    field_id=f"field_{field_counter:03d}",
                    label_region=None,
                    value_region=value,
                    bbox=value.bbox,
                ))

        return fields

    def _spatial_distance(
        self,
        label_bbox: Tuple[int, int, int, int],
        value_bbox: Tuple[int, int, int, int]
    ) -> Tuple[float, str]:
        """Calculate spatial distance and relative direction between two bboxes."""
        lx1, ly1, lx2, ly2 = label_bbox
        vx1, vy1, vx2, vy2 = value_bbox

        # Center points
        lc = ((lx1 + lx2) / 2, (ly1 + ly2) / 2)
        vc = ((vx1 + vx2) / 2, (vy1 + vy2) / 2)

        dx = vc[0] - lc[0]
        dy = vc[1] - lc[1]

        distance = np.sqrt(dx ** 2 + dy ** 2)

        # Determine direction
        if abs(dx) > abs(dy):
            direction = "right" if dx > 0 else "left"
        else:
            direction = "below" if dy > 0 else "above"

        return distance, direction

    def _merge_bboxes(
        self,
        bbox1: Tuple[int, int, int, int],
        bbox2: Tuple[int, int, int, int]
    ) -> Tuple[int, int, int, int]:
        """Merge two bounding boxes into their union."""
        return (
            min(bbox1[0], bbox2[0]),
            min(bbox1[1], bbox2[1]),
            max(bbox1[2], bbox2[2]),
            max(bbox1[3], bbox2[3]),
        )

    def _create_standalone_fields(self, regions: List[TextRegion]) -> List[FormField]:
        """Create fields from regions with no label pairing."""
        fields = []
        for i, region in enumerate(regions):
            fields.append(FormField(
                field_id=f"field_{i+1:03d}",
                label_region=None,
                value_region=region,
                bbox=region.bbox,
            ))
        return fields

    def classify_modality(self, text: str) -> FieldModality:
        """
        Classify the modality of extracted text.
        Used for selecting appropriate confidence weights.
        """
        if not text or not text.strip():
            return FieldModality.TEXT

        stripped = text.strip()

        # Check if purely numeric (with possible spaces)
        if stripped.replace(" ", "").replace(",", "").isdigit():
            return FieldModality.NUMERIC

        # Check for special character patterns (dates, IDs)
        special_chars = set("/-.@#&(){};:")
        alpha_count = sum(1 for c in stripped if c.isalpha())
        digit_count = sum(1 for c in stripped if c.isdigit())
        special_count = sum(1 for c in stripped if c in special_chars)

        total = alpha_count + digit_count + special_count
        if total == 0:
            return FieldModality.TEXT

        special_ratio = special_count / total
        digit_ratio = digit_count / total

        if special_ratio > 0.15:
            return FieldModality.SPECIAL
        elif digit_ratio > 0.7:
            return FieldModality.NUMERIC
        elif digit_ratio > 0.3:
            return FieldModality.MIXED
        else:
            return FieldModality.TEXT
