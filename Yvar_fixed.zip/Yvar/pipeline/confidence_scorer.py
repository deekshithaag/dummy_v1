"""
Confidence Scorer Module (NON-LLM)
Combines 5 independent, measurable signals into a single 0-100 score.
No model self-assessment. All signals are deterministic or statistical.
"""

import numpy as np
import re
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
import logging

from pipeline.layout_analyzer import FieldModality
from pipeline.ocr_engine import MultiOCRResult
from utils.image_quality import ImageQualityMetrics, compute_region_quality
from utils.pattern_validator import PatternValidator
from utils.linguistic_model import LinguisticScorer

logger = logging.getLogger(__name__)


@dataclass
class ConfidenceBreakdown:
    """Detailed breakdown of confidence signals."""
    ocr_confidence: float          # S_ocr: raw engine confidence [0-100]
    cross_engine_agreement: float  # S_agreement: multi-engine consensus [0-100]
    pattern_validation: float      # S_pattern: format validity [0-100]
    image_quality: float           # S_quality: input quality [0-100]
    linguistic_plausibility: float # S_linguistic: text plausibility [0-100]
    final_score: float             # Weighted combination [0-100]
    modality: str                  # Which modality weights were used
    signals_used: Dict[str, float] # Raw signal values before weighting


class ConfidenceScorer:
    """
    Non-LLM confidence scoring engine.

    Fuses 5 independent signals with modality-adaptive weights:
    1. S_ocr - Per-character OCR engine confidence
    2. S_agreement - Cross-engine agreement (edit distance)
    3. S_pattern - Regex/checksum pattern validation
    4. S_quality - Image quality metrics (blur, contrast, skew)
    5. S_linguistic - Character n-gram plausibility

    CRITICAL: None of these signals involve asking a model "how confident are you?"
    All are computed from measurable, deterministic, or statistical properties.
    """

    def __init__(self, config: dict):
        self.weights = config.get("weights", {})
        self.quality_config = config.get("image_quality", {})

        # Initialize sub-scorers
        self.pattern_validator = PatternValidator()
        self.linguistic_scorer = LinguisticScorer()

    def score(
        self,
        ocr_result: MultiOCRResult,
        region_image: np.ndarray,
        modality: FieldModality,
        field_label: str = "",
    ) -> ConfidenceBreakdown:
        """
        Compute confidence score for an extracted field value.

        Args:
            ocr_result: Multi-engine OCR results
            region_image: Cropped image of the field region
            modality: Detected field modality (numeric/text/special/mixed)
            field_label: Optional label text for context-aware scoring

        Returns:
            ConfidenceBreakdown with per-signal scores and final weighted score
        """
        # Signal 1: OCR Engine Confidence
        s_ocr = self._compute_ocr_confidence(ocr_result)

        # Signal 2: Cross-Engine Agreement
        s_agreement = self._compute_agreement(ocr_result)

        # Signal 3: Pattern Validation
        s_pattern = self._compute_pattern_score(ocr_result.best_text, modality, field_label)

        # Signal 4: Image Quality
        s_quality = self._compute_image_quality(region_image)

        # Signal 5: Linguistic Plausibility
        s_linguistic = self._compute_linguistic_score(ocr_result.best_text, modality)

        # Get modality-specific weights
        weights = self._get_weights(modality)

        # Weighted combination
        final_score = (
            weights["ocr_confidence"] * s_ocr
            + weights["cross_engine_agreement"] * s_agreement
            + weights["pattern_validation"] * s_pattern
            + weights["image_quality"] * s_quality
            + weights["linguistic_plausibility"] * s_linguistic
        )

        # Clamp to [0, 100]
        final_score = max(0.0, min(100.0, final_score))

        return ConfidenceBreakdown(
            ocr_confidence=s_ocr,
            cross_engine_agreement=s_agreement,
            pattern_validation=s_pattern,
            image_quality=s_quality,
            linguistic_plausibility=s_linguistic,
            final_score=final_score,
            modality=modality.value,
            signals_used={
                "ocr_confidence": s_ocr,
                "cross_engine_agreement": s_agreement,
                "pattern_validation": s_pattern,
                "image_quality": s_quality,
                "linguistic_plausibility": s_linguistic,
            },
        )

    def _compute_ocr_confidence(self, ocr_result: MultiOCRResult) -> float:
        """
        Signal 1: Raw OCR engine confidence.
        Uses per-character confidences from primary engine.
        Scale: 0-100.
        """
        if not ocr_result.primary.char_confidences:
            # Fallback to overall confidence
            return ocr_result.primary.overall_confidence * 100

        char_confs = ocr_result.primary.char_confidences

        if not char_confs:
            return 0.0

        # Use geometric mean to penalize low-confidence characters more heavily
        # (a single bad character should drag score down)
        log_confs = [np.log(max(c, 1e-10)) for c in char_confs]
        geo_mean = np.exp(np.mean(log_confs))

        return float(geo_mean * 100)

    def _compute_agreement(self, ocr_result: MultiOCRResult) -> float:
        """
        Signal 2: Cross-engine agreement.
        Measures character-level similarity between engines using normalized edit distance.
        Scale: 0-100 (100 = perfect agreement).
        """
        all_texts = [t.strip() for t in ocr_result.all_texts if t.strip()]

        if len(all_texts) <= 1:
            # Only one engine produced results.
            # If primary had high confidence, trust it more.
            if ocr_result.primary.overall_confidence > 0.85:
                return 70.0
            return 50.0

        primary_text = ocr_result.primary.text.strip()

        # If secondary text is very short compared to primary, it likely
        # failed to detect properly on the small crop - don't penalize hard
        secondary_texts = [t.strip() for t in ocr_result.all_texts[1:] if t.strip()]
        if secondary_texts:
            longest_secondary = max(len(t) for t in secondary_texts)
            if primary_text and longest_secondary < len(primary_text) * 0.3:
                # Secondary engine barely detected anything - partial agreement
                if ocr_result.primary.overall_confidence > 0.8:
                    return 60.0
                return 45.0

        # Compute pairwise normalized edit distances
        agreements = []
        for i in range(len(all_texts)):
            for j in range(i + 1, len(all_texts)):
                sim = self._normalized_similarity(all_texts[i], all_texts[j])
                agreements.append(sim)

        if not agreements:
            return 50.0

        # Average pairwise agreement
        avg_agreement = np.mean(agreements)

        return float(avg_agreement * 100)

    def _normalized_similarity(self, s1: str, s2: str) -> float:
        """Compute normalized similarity (1 - normalized_edit_distance)."""
        if not s1 and not s2:
            return 1.0
        if not s1 or not s2:
            return 0.0

        # Levenshtein distance
        distance = self._levenshtein_distance(s1, s2)
        max_len = max(len(s1), len(s2))

        return 1.0 - (distance / max_len)

    def _levenshtein_distance(self, s1: str, s2: str) -> int:
        """Compute Levenshtein edit distance."""
        if len(s1) < len(s2):
            return self._levenshtein_distance(s2, s1)

        if len(s2) == 0:
            return len(s1)

        prev_row = list(range(len(s2) + 1))
        for i, c1 in enumerate(s1):
            curr_row = [i + 1]
            for j, c2 in enumerate(s2):
                insertions = prev_row[j + 1] + 1
                deletions = curr_row[j] + 1
                substitutions = prev_row[j] + (c1 != c2)
                curr_row.append(min(insertions, deletions, substitutions))
            prev_row = curr_row

        return prev_row[-1]

    def _compute_pattern_score(
        self,
        text: str,
        modality: FieldModality,
        label: str = ""
    ) -> float:
        """
        Signal 3: Pattern/format validation.
        Checks if extracted text matches expected formats.
        Scale: 0-100.

        For numeric fields: validates digit structure
        For special fields: validates against known patterns
        For text: basic length/character validity checks
        """
        if not text or not text.strip():
            return 0.0

        text = text.strip()

        # Try all known patterns - if any match perfectly, score is 100
        pattern_match = self.pattern_validator.validate(text, label)
        if pattern_match.is_valid:
            return 100.0

        # Modality-specific scoring
        if modality == FieldModality.NUMERIC:
            return self._score_numeric_pattern(text)
        elif modality == FieldModality.SPECIAL:
            return self._score_special_pattern(text)
        elif modality == FieldModality.TEXT:
            return self._score_text_pattern(text)
        else:  # MIXED
            return self._score_mixed_pattern(text)

    def _score_numeric_pattern(self, text: str) -> float:
        """Score numeric field pattern validity."""
        digits = sum(1 for c in text if c.isdigit())
        spaces = sum(1 for c in text if c == ' ')
        other = len(text) - digits - spaces

        if len(text) == 0:
            return 0.0

        # Numeric fields should be mostly digits
        digit_ratio = digits / len(text.replace(" ", "")) if text.replace(" ", "") else 0
        if digit_ratio >= 0.95:
            return 95.0
        elif digit_ratio >= 0.8:
            return 70.0
        elif digit_ratio >= 0.5:
            return 40.0
        else:
            return 20.0

    def _score_special_pattern(self, text: str) -> float:
        """Score special character field pattern."""
        # Check for common structural patterns
        has_separators = bool(re.search(r'[/\-\.]', text))
        has_mixed = bool(re.search(r'[A-Za-z]', text)) and bool(re.search(r'\d', text))

        score = 50.0  # Base score
        if has_separators:
            score += 20.0
        if has_mixed:
            score += 15.0

        # Check balanced structure
        parts = re.split(r'[/\-\.\s]', text)
        if all(p.strip() for p in parts if p):
            score += 15.0

        return min(100.0, score)

    def _score_text_pattern(self, text: str) -> float:
        """Score text field pattern."""
        if not text:
            return 0.0

        # Text should be mostly alphabetic
        alpha_ratio = sum(1 for c in text if c.isalpha()) / len(text) if text else 0
        has_reasonable_length = 1 <= len(text) <= 200
        no_garbage = not bool(re.search(r'[^\w\s\.\,\-\'\,@]', text))

        score = 40.0
        if alpha_ratio > 0.7:
            score += 30.0
        elif alpha_ratio > 0.4:
            score += 15.0

        if has_reasonable_length:
            score += 15.0
        if no_garbage:
            score += 15.0

        return min(100.0, score)

    def _score_mixed_pattern(self, text: str) -> float:
        """Score mixed field pattern."""
        if not text:
            return 0.0

        has_alpha = bool(re.search(r'[A-Za-z]', text))
        has_digit = bool(re.search(r'\d', text))
        has_reasonable_length = 1 <= len(text) <= 100

        score = 50.0
        if has_alpha and has_digit:
            score += 25.0
        if has_reasonable_length:
            score += 15.0

        # Check for garbage characters
        garbage = sum(1 for c in text if ord(c) < 32 or ord(c) > 126)
        if garbage == 0:
            score += 10.0

        return min(100.0, score)

    def _compute_image_quality(self, region_image: np.ndarray) -> float:
        """
        Signal 4: Image quality of the field region.
        Measures blur, contrast, and local properties.
        Scale: 0-100.
        """
        if region_image is None or region_image.size == 0:
            return 0.0

        metrics = compute_region_quality(region_image)

        # Combine quality indicators
        # Blur: Laplacian variance (higher = sharper)
        blur_score = min(100.0, metrics.laplacian_variance / 5.0)  # Normalize

        # Contrast: standard deviation of pixel values
        contrast_score = min(100.0, metrics.contrast_ratio * 150)

        # Noise: signal-to-noise ratio estimate
        noise_score = min(100.0, metrics.snr * 10)

        # Combined quality score
        quality = 0.5 * blur_score + 0.3 * contrast_score + 0.2 * noise_score

        return max(0.0, min(100.0, quality))

    def _compute_linguistic_score(self, text: str, modality: FieldModality) -> float:
        """
        Signal 5: Linguistic plausibility.
        Uses character n-gram frequency analysis (NOT an LLM).
        Scale: 0-100.

        For numeric fields: this signal has low weight anyway
        For text fields: checks if character sequences are plausible for the language
        """
        if not text or not text.strip():
            return 0.0

        # For purely numeric fields, linguistic scoring is less meaningful
        if modality == FieldModality.NUMERIC:
            # Just check that it looks like valid numbers
            clean = text.replace(" ", "").replace(",", "")
            if clean.isdigit():
                return 90.0
            return 40.0

        return self.linguistic_scorer.score(text)

    def _get_weights(self, modality: FieldModality) -> Dict[str, float]:
        """Get modality-specific signal weights."""
        modality_key = modality.value
        if modality_key in self.weights:
            return self.weights[modality_key]

        # Default balanced weights
        return {
            "ocr_confidence": 0.20,
            "cross_engine_agreement": 0.25,
            "pattern_validation": 0.20,
            "image_quality": 0.15,
            "linguistic_plausibility": 0.20,
        }

    def rescore(
        self,
        text: str,
        ocr_result: MultiOCRResult,
        region_image: np.ndarray,
        modality: FieldModality,
        field_label: str = "",
    ) -> ConfidenceBreakdown:
        """
        Re-score after a repair attempt.
        Creates a modified OCR result with the new text and re-computes all signals.
        """
        # Update the best_text in OCR result for pattern/linguistic scoring
        modified_result = MultiOCRResult(
            primary=ocr_result.primary,
            secondary=ocr_result.secondary,
            all_texts=ocr_result.all_texts,
            best_text=text,
            best_confidence=ocr_result.best_confidence,
        )

        return self.score(modified_result, region_image, modality, field_label)
