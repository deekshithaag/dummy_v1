"""
Uncorrectable Handler
Reports fields that could not be recovered by self-repair.
Provides diagnostic information for human review.
"""

from enum import Enum
from typing import List, Dict, Optional
from dataclasses import dataclass, asdict

from pipeline.self_repair import RepairResult, RepairAttempt
from pipeline.confidence_scorer import ConfidenceBreakdown


class FailureType(Enum):
    """Structured failure taxonomy for uncorrectable fields."""
    SEVERE_BLUR = "severe_blur"
    LOW_CONTRAST = "low_contrast"
    OVERLAPPING_HANDWRITING = "overlapping_handwriting"
    MULTILINGUAL_MIX = "multilingual_mix"
    CUTOFF_REGION = "cutoff_region"
    SEGMENTATION_FAILURE = "segmentation_failure"
    LOW_RESOLUTION = "low_resolution"
    ENGINE_DISAGREEMENT = "engine_disagreement"
    PATTERN_MISMATCH = "pattern_mismatch"
    LINGUISTIC_ANOMALY = "linguistic_anomaly"
    COMBINED_DEGRADATION = "combined_degradation"


@dataclass
class UncorrectableReport:
    """Detailed report for a field that could not be fully recovered."""
    field_id: str
    field_label: str
    best_value: str
    final_confidence: float
    target_confidence: float  # 100%
    confidence_gap: float
    repair_attempts: List[Dict]
    failure_type: str          # FailureType enum value
    failure_reason: str
    failure_signals: Dict[str, float]  # Which signals are lowest
    recommended_action: str


class UncorrectableHandler:
    """
    Handles fields that remain below 100% confidence after self-repair.
    Provides diagnostic information and failure analysis.
    """

    def __init__(self, config: dict = None):
        self.human_review_threshold = (config or {}).get("human_review_threshold", 70)

    def report(
        self,
        field_id: str,
        field_label: str,
        repair_result: RepairResult,
        confidence_breakdown: ConfidenceBreakdown,
    ) -> UncorrectableReport:
        """
        Generate uncorrectable report with diagnostics.
        Identifies root cause of failure and recommends action.
        """
        # Identify weakest signals
        signals = confidence_breakdown.signals_used
        sorted_signals = sorted(signals.items(), key=lambda x: x[1])
        weakest = sorted_signals[:2]  # Two lowest signals

        # Determine failure reason and type
        failure_type, failure_reason = self._diagnose_failure(weakest, confidence_breakdown)

        # Format repair attempts
        attempt_records = []
        for attempt in repair_result.attempts:
            attempt_records.append({
                "strategy": attempt.strategy,
                "description": attempt.description,
                "value_before": attempt.value_before,
                "value_after": attempt.value_after,
                "confidence_change": f"{attempt.confidence_before:.1f}% -> {attempt.confidence_after:.1f}%",
                "improvement": f"{attempt.improvement:+.1f}%",
                "success": attempt.success,
            })

        # Recommend action
        recommended_action = self._recommend_action(
            confidence_breakdown.final_score, weakest
        )

        return UncorrectableReport(
            field_id=field_id,
            field_label=field_label,
            best_value=repair_result.final_value,
            final_confidence=repair_result.final_confidence,
            target_confidence=100.0,
            confidence_gap=100.0 - repair_result.final_confidence,
            repair_attempts=attempt_records,
            failure_type=failure_type.value,
            failure_reason=failure_reason,
            failure_signals={k: v for k, v in weakest},
            recommended_action=recommended_action,
        )

    def _diagnose_failure(
        self, weakest_signals: List[tuple], breakdown: ConfidenceBreakdown
    ) -> tuple:
        """Diagnose why the field could not be recovered. Returns (FailureType, reason_str)."""
        reasons = []
        primary_failure = FailureType.COMBINED_DEGRADATION

        for signal_name, signal_value in weakest_signals:
            if signal_name == "image_quality" and signal_value < 50:
                reasons.append(
                    f"Poor image quality (score: {signal_value:.0f}/100) — "
                    f"region may be blurry, low contrast, or heavily skewed"
                )
                if signal_value < 25:
                    primary_failure = FailureType.SEVERE_BLUR
                else:
                    primary_failure = FailureType.LOW_CONTRAST
            elif signal_name == "cross_engine_agreement" and signal_value < 50:
                reasons.append(
                    f"Low cross-engine agreement (score: {signal_value:.0f}/100) — "
                    f"OCR engines disagree on the text, indicating ambiguous handwriting"
                )
                primary_failure = FailureType.ENGINE_DISAGREEMENT
            elif signal_name == "ocr_confidence" and signal_value < 50:
                reasons.append(
                    f"Low OCR confidence (score: {signal_value:.0f}/100) — "
                    f"characters are unclear or partially occluded"
                )
                primary_failure = FailureType.SEGMENTATION_FAILURE
            elif signal_name == "pattern_validation" and signal_value < 50:
                reasons.append(
                    f"Pattern validation failed (score: {signal_value:.0f}/100) — "
                    f"extracted text doesn't match expected structural format"
                )
                primary_failure = FailureType.PATTERN_MISMATCH
            elif signal_name == "linguistic_plausibility" and signal_value < 50:
                reasons.append(
                    f"Low linguistic plausibility (score: {signal_value:.0f}/100) — "
                    f"character sequences are unusual, possibly garbled"
                )
                primary_failure = FailureType.LINGUISTIC_ANOMALY

        if not reasons:
            reasons.append(
                f"Multiple signals below threshold — "
                f"combined degradation across quality dimensions"
            )
            primary_failure = FailureType.COMBINED_DEGRADATION

        return primary_failure, "; ".join(reasons)

    def _recommend_action(
        self, final_confidence: float, weakest_signals: List[tuple]
    ) -> str:
        """Recommend appropriate action for the uncorrectable field."""
        if final_confidence >= 80:
            return "MANUAL_VERIFY - Value is likely correct but needs human verification"
        elif final_confidence >= 50:
            # Check if it's an image quality issue
            quality_issues = [s for s, v in weakest_signals if s == "image_quality"]
            if quality_issues:
                return "RESCAN_REQUIRED - Image quality too poor, request better scan"
            else:
                return "MANUAL_ENTRY - Value unreliable, requires manual data entry"
        else:
            return "REJECT_AND_RESCAN - Value cannot be trusted, document needs rescanning"
