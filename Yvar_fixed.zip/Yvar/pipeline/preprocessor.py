"""
Preprocessor Module
Converts PDF pages to preprocessed images ready for OCR.
Handles PDF-image conversion, deskewing, denoising, binarization.
"""

import os
import numpy as np
import cv2
from typing import List, Tuple, Optional
from dataclasses import dataclass
import logging

import fitz  # PyMuPDF – no system binaries needed

logger = logging.getLogger(__name__)


@dataclass
class PreprocessedPage:
    """A single preprocessed page with metadata."""
    page_number: int
    original_image: np.ndarray
    processed_image: np.ndarray
    grayscale: np.ndarray
    skew_angle: float
    dpi: int


class Preprocessor:
    """Converts PDF to preprocessed images with multiple enhancement options."""

    def __init__(self, config: dict):
        self.dpi = config.get("dpi", 300)
        self.max_side = config.get("max_side", 2400)
        self.binarization_methods = config.get(
            "binarization_methods", ["sauvola", "niblack", "adaptive_gaussian"]
        )
        self.denoise_strength = config.get("denoise_strength", 10)
        self.max_skew_angle = config.get("max_skew_angle", 15)

    def pdf_to_images(self, pdf_path: str) -> List[np.ndarray]:
        """Convert PDF pages to numpy arrays using PyMuPDF (no system deps)."""
        if not os.path.exists(pdf_path):
            raise FileNotFoundError(f"PDF not found: {pdf_path}")

        doc = fitz.open(pdf_path)
        images = []

        for page_id in doc:
            zoom = self.dpi / 72.0
            mat = fitz.Matrix(zoom, zoom)
            pix = page_id.get_pixmap(matrix=mat)

            img = np.frombuffer(pix.samples, dtype=np.uint8).reshape(
                pix.height, pix.width, pix.n
            )
            images.append(img)

        doc.close()
        return images

    def process_pdf(self, pdf_path: str) -> List[PreprocessedPage]:
        """Full preprocessing pipeline for a PDF file."""
        raw_images = self.pdf_to_images(pdf_path)
        pages = []

        for i, img in enumerate(raw_images):
            page = self._process_single_page(img, page_number=i + 1)
            pages.append(page)

        return pages

    def _process_single_page(self, image: np.ndarray, page_number: int) -> PreprocessedPage:
        """Process a single page."""
        h, w = image.shape[:2]
        if max(h, w) > self.max_side:
            scale = self.max_side / max(h, w)
            new_w = int(w * scale)
            new_h = int(h * scale)
            image = cv2.resize(image, (new_w, new_h), interpolation=cv2.INTER_AREA)

        # Convert RGBA to RGB if needed
        if len(image.shape) == 3 and image.shape[2] == 4:
            image = cv2.cvtColor(image, cv2.COLOR_RGBA2RGB)

        # Convert to grayscale
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        else:
            gray = image.copy()

        # Detect and correct skew
        skew_angle = self._detect_skew(gray)
        if abs(skew_angle) > 0.5 and abs(skew_angle) < self.max_skew_angle:
            corrected = self._deskew(gray, skew_angle)
        else:
            corrected = gray
            skew_angle = 0.0

        denoised = self._denoise(corrected)
        processed = self._binarize(denoised, method="otsu")

        return PreprocessedPage(
            page_number=page_number,
            original_image=image,
            processed_image=processed,
            grayscale=gray,
            skew_angle=skew_angle,
            dpi=self.dpi,
        )

    def _detect_skew(self, gray: np.ndarray) -> float:
        """Detect document skew using Hough Line Transform."""
        edges = cv2.Canny(gray, 50, 150, apertureSize=3)
        lines = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=100,
                                minLineLength=100, maxLineGap=10)
        if lines is None:
            return 0.0

        angles = []
        for line in lines:
            x1, y1, x2, y2 = line[0]
            angle = np.degrees(np.arctan2(y2 - y1, x2 - x1))
            if abs(angle) < self.max_skew_angle:
                angles.append(angle)

        if not angles:
            return 0.0

        return float(np.median(angles))

    def _deskew(self, image: np.ndarray, angle: float) -> np.ndarray:
        """Rotate image to correct skew."""
        h, w = image.shape[:2]
        center = (w // 2, h // 2)
        matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
        rotated = cv2.warpAffine(
            image, matrix, (w, h),
            flags=cv2.INTER_LINEAR,
            borderMode=cv2.BORDER_REPLICATE
        )
        return rotated

    def _denoise(self, image: np.ndarray) -> np.ndarray:
        """Apply non-local means denoising."""
        return cv2.fastNlMeansDenoising(
            image, None, h=self.denoise_strength, templateWindowSize=7, searchWindowSize=21
        )

    def _binarize(self, image: np.ndarray, method: str = "otsu") -> np.ndarray:
        """Apply binarization with specified method."""
        if method == "otsu":
            _, binary = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        elif method == "sauvola":
            binary = self._sauvola_threshold(image)
        elif method == "niblack":
            binary = self._niblack_threshold(image)
        elif method == "adaptive_gaussian":
            binary = cv2.adaptiveThreshold(
                image, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                cv2.THRESH_BINARY, 31, 10
            )
        elif method == "clahe":
            binary = self._clahe_enhanced(image)
        else:
            _, binary = cv2.threshold(image, 127, 255, cv2.THRESH_BINARY)

        return binary

    def _clahe_enhanced(self, image: np.ndarray) -> np.ndarray:
        """CLAHE contrast enhancement then Otsu binarization."""
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        enhanced = clahe.apply(image)
        _, binary = cv2.threshold(enhanced, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        return binary

    def _sauvola_threshold(self, image: np.ndarray, window_size: int = 25, k: float = 0.08) -> np.ndarray:
        """Sauvola binarization - good for uneven illumination."""
        mean = cv2.blur(image.astype(np.float64), (window_size, window_size))
        sqr_mean = cv2.blur(image.astype(np.float64) ** 2, (window_size, window_size))
        std = np.sqrt(np.maximum(sqr_mean - mean ** 2, 0))
        threshold = mean * (1.0 + k * (std / 128.0 - 1.0))
        binary = np.zeros_like(image)
        binary[image >= threshold] = 255
        return binary.astype(np.uint8)

    def _niblack_threshold(self, image: np.ndarray, window_size: int = 25, k: float = -0.2) -> np.ndarray:
        """Niblack binarization."""
        mean = cv2.blur(image.astype(np.float64), (window_size, window_size))
        sqr_mean = cv2.blur(image.astype(np.float64) ** 2, (window_size, window_size))
        std = np.sqrt(np.maximum(sqr_mean - mean ** 2, 0))
        threshold = mean + k * std
        binary = np.zeros_like(image)
        binary[image >= threshold] = 255
        return binary.astype(np.uint8)

    def reprocess_region(
        self, image: np.ndarray, bbox: Tuple[int, int, int, int],
        method: str = "otsu", expand_ratio: float = 0.0
    ) -> np.ndarray:
        """Process a specific region with different parameters (for self-repair)."""
        x1, y1, x2, y2 = bbox

        if expand_ratio > 0:
            h, w = image.shape[:2]
            dx = int((x2 - x1) * expand_ratio)
            dy = int((y2 - y1) * expand_ratio)
            x1 = max(0, x1 - dx)
            y1 = max(0, y1 - dy)
            x2 = min(w, x2 + dx)
            y2 = min(h, y2 + dy)

        region = image[y1:y2, x1:x2]

        if len(region.shape) == 3:
            region = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY)

        denoised = self._denoise(region)
        binary = self._binarize(denoised, method=method)

        return binary

    def super_resolve(self, image: np.ndarray, scale: int = 4) -> np.ndarray:
        """Upscale image region using bilinear interpolation."""
        h, w = image.shape[:2]
        upscaled = cv2.resize(
            image, (w * scale, h * scale), interpolation=cv2.INTER_CUBIC
        )
        kernel = np.array([[-1, -1, -1], [-1, 8, -1], [-1, -1, -1]])
        sharpened = cv2.filter2D(upscaled, -1, kernel)
        return np.clip(sharpened, 0, 255).astype(np.uint8)
