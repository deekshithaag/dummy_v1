# Document Sourcing Guide

## Sourcing Strategy

All sample documents must be **publicly available** and contain **handwritten content** on printed form templates.

## Recommended Sources

### 1. Government Form Samples (Handwritten)
- **Kaggle datasets**: Search "handwritten forms", "filled forms", "document OCR"
  - https://www.kaggle.com/datasets - search for "handwritten form"
  - FUNSD dataset (Form Understanding in Noisy Scanned Documents)
  - IAM Handwriting Database (handwritten text samples)

### 2. Indian Document Samples
- Aadhaar/PAN sample images (redacted/sample versions from government sites)
- Educational mark sheets with handwritten marks
- Search: "filled application form sample pdf handwritten"

### 3. Specific Dataset Recommendations

| Dataset | Content | Link |
|---------|---------|------|
| FUNSD | Noisy scanned forms with annotations | https://guillaumejaume.github.io/FUNSD/ |
| IAM Forms | Handwritten text on forms | https://fki.tic.heia-fr.ch/databases/iam-handwriting-database |
| NIST SD19 | Handwritten digits and characters | https://www.nist.gov/srd/nist-special-database-19 |
| HW-SQuAD | Handwritten answers | Available on Kaggle |
| IMGURSK | Handwritten text in natural images | https://github.com/facebookresearch/IMGURSK-Handwriting-Dataset |

### 4. Self-Created Samples
If not easily found online, create your own:
1. Download blank form templates (government/educational)
2. Fill by hand with varied handwriting styles
3. Scan at 300 DPI
4. Include intentional challenges: slight skew, varied pen pressure

## Minimum Coverage (15-20 Documents)

### Required Categories:
- [ ] 3-4 forms with **numbers** (Aadhaar-like, phone numbers, amounts)
- [ ] 3-4 forms with **text** (names, addresses)
- [ ] 3-4 forms with **special characters** (dates, email-like, IDs)
- [ ] 2-3 **mark sheets** with handwritten scores
- [ ] 3-4 **deliberately difficult** samples:
  - Skewed scan (10-15 degrees)
  - Low contrast (faded ink / poor photocopy)
  - Partial handwriting (incomplete fields)
  - Mixed languages (English + Hindi/regional)
  - Special characters mixed with handwriting

## Selection Criteria

### Accept if:
- Clearly handwritten content on printed template
- Publicly available (no privacy concerns)
- Variety of handwriting styles
- Mix of field types (numeric, text, dates, IDs)

### Reject if:
- Contains real personal information (PII)
- Purely printed text (no handwriting)
- Too low resolution (< 150 DPI equivalent)
- Copyrighted material without appropriate license

## Document Preparation
1. Convert all samples to PDF (if not already)
2. Ensure 300 DPI resolution
3. Store in `samples/` directory
4. Name convention: `category_number.pdf` (e.g., `application_01.pdf`, `marksheet_03.pdf`)

## Rejected Documents Log
Document rejection reasons in `docs/writeup.md`:
- Document name/source
- Reason for rejection
- What made it unsuitable
