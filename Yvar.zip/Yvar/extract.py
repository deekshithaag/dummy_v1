"""
extract.py - CLI Entry Point
Generic Handwritten-Form Extraction Pipeline

Usage:
    python extract.py --input <pdf_path> --output <json_path>
    python extract.py --input <pdf_path> --output <json_path> --config <config_path>
    python extract.py --input <folder> --output <folder> --batch
"""

import os
import sys
import json
import time
import logging
from pathlib import Path
from typing import Optional

import click
import yaml
import numpy as np

from pipeline.preprocessor import Preprocessor
from pipeline.layout_analyzer import LayoutAnalyzer, FieldModality
from pipeline.ocr_engine import OCREngine
from pipeline.field_extractor import FieldExtractor
from pipeline.confidence_scorer import ConfidenceScorer
from pipeline.self_repair import SelfRepairLoop
from pipeline.uncorrectable_handler import UncorrectableHandler
from pipeline.output_assembler import OutputAssembler
from utils.debug_visualizer import generate_debug_outputs


def load_config(config_path: str) -> dict:
    """Load pipeline configuration from YAML."""
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


def setup_logging(verbose: bool = False):
    """Configure logging."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )


class ExtractionPipeline:
    """
    Main pipeline orchestrator.
    Coordinates all modules: preprocessing -> layout -> OCR -> scoring -> repair -> output.
    """

    def __init__(self, config: dict):
        self.config = config
        self.confirm_threshold = config.get("self_repair", {}).get("confirm_threshold", 80.0)

        # Initialize modules
        self.preprocessor = Preprocessor(config.get("preprocessing", {}))
        self.ocr_engine = OCREngine(config.get("ocr_engines", {}))
        self.field_extractor = FieldExtractor(
            config.get("layout_analysis", {}), self.ocr_engine
        )
        self.confidence_scorer = ConfidenceScorer(config.get("confidence_scoring", {}))
        self.self_repair = SelfRepairLoop(
            config.get("self_repair", {}),
            self.preprocessor,
            self.ocr_engine,
            self.confidence_scorer,
        )
        self.uncorrectable_handler = UncorrectableHandler(config.get("output", {}))
        self.output_assembler = OutputAssembler(config.get("output", {}))

    def process_pdf(self, pdf_path: str, output_dir: str = None) -> dict:
        """
        Process a single PDF end-to-end.

        Returns structured JSON output with all fields, confidence scores,
        repair history, and uncorrectable reports.
        """
        logger = logging.getLogger(__name__)
        start_time = time.time()

        logger.info(f"Processing: {pdf_path}")

        # Step 1: Preprocessing - PDF to images
        logger.info("Step 1/6: Preprocessing PDF...")
        pages = self.preprocessor.process_pdf(pdf_path)
        logger.info(f"  Converted {len(pages)} pages at {self.preprocessor.dpi} DPI")

        all_fields = []
        all_confidences = []
        all_repairs = []
        all_uncorrectable = []

        for page in pages:
            logger.info(f"\n----- Page {page.page_number} -----")

            # Step 2: Layout Analysis & Field Extraction
            logger.info("Step 2/6: Detecting fields...")
            fields = self.field_extractor.extract_fields(
                page.processed_image, page.grayscale
            )
            logger.info(f"  Extracted {len(fields)} fields")

            page_fields = []
            page_confidences = []
            page_repairs = []

            for field in fields:
                # Step 3: Confidence Scoring
                logger.info(f"Step 3/6: Scoring '{field.label}' = '{field.value[:30]}...'")
                x1, x2, y1, y2 = field.value_bbox or field.bbox
                region_image = page.grayscale[y1:y2, x1:x2]

                confidence = self.confidence_scorer.score(
                    ocr_result=field.ocr_result,
                    region_image=region_image,
                    modality=field.modality,
                    field_label=field.label,
                )
                logger.info(f"  Confidence: {confidence.final_score:.1f}%")

                # Step 4: Self-Repair (if confidence below threshold)
                repair_result = None
                if confidence.final_score < self.confirm_threshold:
                    logger.info(
                        f"Step 4/6: Self-repair triggered (conf={confidence.final_score:.1f}% < {self.confirm_threshold}%)"
                    )
                    repair_result = self.self_repair.repair(
                        current_value=field.value,
                        current_confidence=confidence,
                        page_image=page.grayscale,
                        bbox=field.value_bbox or field.bbox,
                        modality=field.modality,
                        field_label=field.label,
                        ocr_result=field.ocr_result,
                    )
                    logger.info(
                        f"  Repair result: {repair_result.original_confidence:.1f}% -> "
                        f"{repair_result.final_confidence:.1f}% "
                        f"({repair_result.total_iterations} attempts)"
                    )

                # Re-score after repair
                if repair_result and repair_result.is_repaired:
                    confidence = self.confidence_scorer.rescore(
                        text=repair_result.final_value,
                        ocr_result=field.ocr_result,
                        region_image=region_image,
                        modality=field.modality,
                        field_label=field.label,
                    )

                # Step 5: Uncorrectable Handling
                uncorrectable_report = None
                if repair_result and repair_result.is_uncorrectable:
                    logger.info("Step 5/6: Field marked uncorrectable")
                    uncorrectable_report = self.uncorrectable_handler.report(
                        field_id=field.field_id,
                        field_label=field.label,
                        repair_result=repair_result,
                        confidence_breakdown=confidence,
                    )
                    logger.info(f"  Reason: {uncorrectable_report.failure_reason[:80]}...")

                all_fields.append(field)
                all_confidences.append(confidence)
                all_repairs.append(repair_result)
                all_uncorrectable.append(uncorrectable_report)
                page_fields.append(field)
                page_confidences.append(confidence)
                page_repairs.append(repair_result)

            # Generate debug visualizations for this page
            if output_dir and page_fields:
                try:
                    generate_debug_outputs(
                        page.grayscale, page_fields, page_confidences,
                        page_repairs, output_dir, page.page_number,
                    )
                    logger.info(f"  Debug visuals saved to {output_dir}/debug/")
                except Exception as e:
                    logger.warning(f"  Debug visualization failed: {e}")

        # Step 6: Output Assembly
        logger.info("\nStep 6/6: Assembling output...")
        elapsed = time.time() - start_time

        metadata = {
            "input_file": os.path.basename(pdf_path),
            "pages_processed": len(pages),
            "processing_time_seconds": round(elapsed, 2),
            "pipeline_version": "1.0.0",
            "dpi": self.preprocessor.dpi,
        }

        output = self.output_assembler.assemble(
            fields=all_fields,
            confidence_scores=all_confidences,
            repair_results=all_repairs,
            uncorrectable_reports=all_uncorrectable,
            metadata=metadata,
        )

        # Log summary
        summary = output["summary"]
        logger.info("\n" + "=" * 50)
        logger.info(f"SUMMARY: {summary['total_fields']} fields extracted")
        logger.info(f"  Confirmed (100%): {summary['confirmed']}")
        logger.info(f"  Repaired: {summary['repaired']}")
        logger.info(f"  Uncorrectable: {summary['uncorrectable']}")
        logger.info(f"  Avg confidence: {summary['avg_confidence']:.2f}%")
        logger.info(f"  Processing time: {elapsed:.2f}s")
        logger.info("=" * 50)

        return output


@click.command()
@click.option("--input", "input_path", required=True, help="Input PDF path or folder")
@click.option("--output", "output_path", required=True, help="Output JSON path or folder")
@click.option(
    "--config",
    "config_path",
    default="config/pipeline_config.yaml",
    help="Pipeline configuration file",
)
@click.option("--batch", is_flag=True, help="Process all PDFs in input folder")
@click.option("--verbose", is_flag=True, help="Enable debug logging")
@click.option("--debug-visuals", is_flag=True, help="Generate debug visualizations (bounding boxes, heatmaps)")
def main(input_path: str, output_path: str, config_path: str, batch: bool, verbose: bool, debug_visuals: bool):
    """
    Generic Handwritten-Form Extraction Pipeline.

    Extracts all fields from scanned PDF forms with non-LLM confidence scoring
    and self-repair capabilities.
    """
    setup_logging(verbose)
    logger = logging.getLogger(__name__)

    # Load configuration
    if os.path.exists(config_path):
        config = load_config(config_path)
        logger.info(f"Loaded config from {config_path}")
    else:
        logger.warning(f"Config not found at {config_path}, using defaults")
        config = {}

    # Initialize pipeline
    pipeline = ExtractionPipeline(config)

    if batch:
        # Batch mode: process all PDFs in folder
        input_dir = Path(input_path)
        output_dir = Path(output_path)
        output_dir.mkdir(parents=True, exist_ok=True)

        pdf_files = list(input_dir.glob("*.pdf")) + list(input_dir.glob("*.PDF"))
        logger.info(f"Found {len(pdf_files)} PDFs to process")

        for pdf_file in pdf_files:
            output_file = output_dir / f"{pdf_file.stem}.json"
            try:
                debug_dir = str(output_dir / pdf_file.stem) if debug_visuals else None
                result = pipeline.process_pdf(str(pdf_file), output_dir=debug_dir)
                with open(output_file, "w", encoding="utf-8") as f:
                    json.dump(result, f, indent=2, ensure_ascii=False)
                logger.info(f"Saved: {output_file}")
            except Exception as e:
                logger.error(f"Failed to process {pdf_file}: {e}")
    else:
        # Single file mode
        if not os.path.exists(input_path):
            logger.error(f"Input file not found: {input_path}")
            sys.exit(1)

        result = pipeline.process_pdf(
            input_path,
            output_dir=os.path.dirname(output_path) if debug_visuals else None,
        )

        # Write output
        output_dir = os.path.dirname(output_path)
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, ensure_ascii=False)

        logger.info(f"Output saved to: {output_path}")


if __name__ == "__main__":
    main()
